# 🌊 全球海缆完整信息表

**数据来源**: TeleGeography Submarine Cable Map
**总数量**: 691 条海缆
**生成时间**: 2026-03-25

## 🌐 其他 (691 条)

| 名称 | 长度 | 投产年份 | 状态 | 主要国家 |
|------|------|----------|------|----------|
| Tenerife-La Palma | None | None | ✅ 运营中 |  |
| Project Waterworth | 50,000 km | None | 🔮 规划中 |  |
| La Gomera-El Hierro | None | None | ✅ 运营中 |  |
| Barat Timur Indonesia-2 (BTI-2) | 11,600 km | None | 🔮 规划中 |  |
| ANDROMEDA | None | None | 🔮 规划中 |  |
| Taihei | 7,000 km | 2029 | 🔮 规划中 |  |
| IOEMA-1 | 1,667 km | 2029 | 🔮 规划中 |  |
| I-AM Cable | 8,100 km | 2029 | 🔮 规划中 |  |
| Halaihai | 17,483 km | 2029 | 🔮 规划中 |  |
| E2A | 12,500 km | 2029 | 🔮 规划中 |  |
| Bosun | None | 2029 | 🔮 规划中 |  |
| Asia United Gateway East (AUG East) | 8,900 km | 2029 | 🔮 规划中 |  |
| Verena | 630 km | 2028 | 🔮 规划中 |  |
| Umoja | None | 2028 | 🔮 规划中 |  |
| TalayLink | None | 2028 | 🔮 规划中 |  |
| Sol | 8,153 km | 2028 | 🔮 规划中 |  |
| SX Tasman Express (SX-TX) | 2,276 km | 2028 | 🔮 规划中 |  |
| Norte Conectado (Infovia 08) | 2,766 km | 2028 | 🔮 规划中 |  |
| Norte Conectado (Infovia 06) | 2,847 km | 2028 | 🔮 规划中 |  |
| Norte Conectado (Infovia 05) | 1,116 km | 2028 | 🔮 规划中 |  |
| MANTA | 5,600 km | 2028 | 🔮 规划中 |  |
| Lake Michigan Crossing Peninsula and Island Connection | None | 2028 | 🔮 规划中 |  |
| Lake Michigan Chicago Crossing | None | 2028 | 🔮 规划中 |  |
| GC-LNZ-FU Ring | 553 km | 2028 | 🔮 规划中 |  |
| Fastnet | None | 2028 | 🔮 规划中 |  |
| EAGLE | 1,900 km | 2028 | 🔮 规划中 |  |
| Dhivaru | None | 2028 | 🔮 规划中 |  |
| Confluence-1 | 2,571 km | 2028 | 🔮 规划中 |  |
| Candle | 8,000 km | 2028 | 🔮 规划中 |  |
| Barracuda | 1,050 km | 2028 | 🔮 规划中 |  |
| Barat Timur Indonesia-1 (BTI-1) | 4,500 km | 2028 | 🔮 规划中 |  |
| Asia Connect Cable-1 (ACC-1) | 19,000 km | 2028 | 🔮 规划中 |  |
| Arctic Way | 2,568 km | 2028 | 🔮 规划中 |  |
| APX East | 13,000 km | 2028 | 🔮 规划中 |  |
| Vietnam-Singapore Cable System (VTS) | None | 2027 | 🔮 规划中 |  |
| Thetis Express | 340 km | 2027 | 🔮 规划中 |  |
| Tasman Ring Network | 6,000 km | 2027 | 🔮 规划中 |  |
| Tamtam | 1,000 km | 2027 | 🔮 规划中 |  |
| Sunoque III | 125 km | 2027 | 🔮 规划中 |  |
| SeaMeWe-6 | 21,700 km | 2027 | 🔮 规划中 |  |
| PASELA | 1,100 km | 2027 | 🔮 规划中 |  |
| ORCA | 12,482 km | 2027 | 🔮 规划中 |  |
| Nome to Homer Express (NTHE) | 1,545 km | 2027 | 🔮 规划中 |  |
| Mobily Red Sea Cable (MRSC) | None | 2027 | 🔮 规划中 |  |
| Mjolner West | 250 km | 2027 | 🔮 规划中 |  |
| Mjolner East | 450 km | 2027 | 🔮 规划中 |  |
| Kattegat Cable | 92 km | 2027 | 🔮 规划中 |  |
| Kardesa | 1,385 km | 2027 | 🔮 规划中 |  |
| JAKO | 260 km | 2027 | 🔮 规划中 |  |
| Indonesia Tengah Cable Systems | 2,641 km | 2027 | 🔮 规划中 |  |
| Hawaiki Nui 1 | 10,000 km | 2027 | 🔮 规划中 |  |
| Fibre in Gulf (FIG) | 1,931 km | 2027 | 🔮 规划中 |  |
| FISH West | 276 km | 2027 | 🔮 规划中 |  |
| FISH South | 900 km | 2027 | 🔮 规划中 |  |
| Eastern Light Sweden-Finland II | None | 2027 | 🔮 规划中 |  |
| EMC West-2 | 3,978 km | 2027 | 🔮 规划中 |  |
| EMC West-1 | 3,639 km | 2027 | 🔮 规划中 |  |
| EAUFON 3 | 900 km | 2027 | 🔮 规划中 |  |
| CELIA | 3,700 km | 2027 | 🔮 规划中 |  |
| Beaufort | 158 km | 2027 | 🔮 规划中 |  |
| Asia Link Cable (ALC) | 7,200 km | 2027 | 🔮 规划中 |  |
| Africa-1 | 10,000 km | 2027 | 🔮 规划中 |  |
| Adamasia Cable System 1 | 1,015 km | 2027 | 🔮 规划中 |  |
| VAKA | 668 km | 2026 | 🔮 规划中 |  |
| Trans-Caspian Fiber Optic Cable Project | 380 km | 2026 | 🔮 规划中 |  |
| Trans Global Cable System (TGCS) | 1,200 km | 2026 | 🔮 规划中 |  |
| Taiwan-Matsu No.4 | 300 km | 2026 | 🔮 规划中 |  |
| Tabua | None | 2026 | 🔮 规划中 |  |
| TPU | 13,470 km | 2026 | 🔮 规划中 |  |
| TIKAL-AMX3 | 1,935 km | 2026 | 🔮 规划中 |  |
| TAM-1 | 7,200 km | 2026 | 🔮 规划中 |  |
| Sydney-Melbourne-Adelaide-Perth (SMAP) | 5,000 km | 2026 | 🔮 规划中 |  |
| Sihanoukville-Hong Kong (SHV-HK) | 2,938 km | 2026 | 🔮 规划中 |  |
| SEA-H2X | 6,000 km | 2026 | 🔮 规划中 |  |
| Raman | 7,376 km | 2026 | 🔮 规划中 |  |
| RISING 8 | 1,104 km | 2026 | 🔮 规划中 |  |
| Q&E South | 141 km | 2026 | 🔮 规划中 |  |
| Proa | 2,891 km | 2026 | 🔮 规划中 |  |
| Olisipo | 110 km | 2026 | 🔮 规划中 |  |
| Nuvem | 7,194 km | 2026 | 🔮 规划中 |  |
| Norte Conectado (Infovia 04) | 515 km | 2026 | 🔮 规划中 |  |
| Norte Conectado (Infovia 02) | 1,796 km | 2026 | 🔮 规划中 |  |
| Nongsa-Changi | 50 km | 2026 | 🔮 规划中 |  |
| New CAM Ring | 3,812 km | 2026 | 🔮 规划中 |  |
| Medusa Submarine Cable System | 8,760 km | 2026 | 🔮 规划中 |  |
| Le Vasa | None | 2026 | 🔮 规划中 |  |
| India Europe Xpress (IEX) | 9,775 km | 2026 | 🔮 规划中 |  |
| INSICA | 100 km | 2026 | 🔮 规划中 |  |
| Honomoana | 15,215 km | 2026 | 🔮 规划中 |  |
| Hawaiian Islands Fiber Link (HIFL) | 740 km | 2026 | 🔮 规划中 |  |
| East Micronesia Cable System (EMCS) | 2,250 km | 2026 | 🔮 规划中 |  |
| Daraja | 4,108 km | 2026 | 🔮 规划中 |  |
| Carnival Submarine Network-1 (CSN-1) | 4,670 km | 2026 | 🔮 规划中 |  |
| CADMOS-2 | 250 km | 2026 | 🔮 规划中 |  |
| Bulikula | 21,600 km | 2026 | 🔮 规划中 |  |
| Bangladesh Private Cable System (BPCS) | 1,300 km | 2026 | 🔮 规划中 |  |
| Anjana | 7,121 km | 2026 | 🔮 规划中 |  |
| Unitirreno | 1,156 km | 2025 | ✅ 运营中 |  |
| Timor-Leste South Submarine Cable (TLSSC) | 607 km | 2025 | ✅ 运营中 |  |
| TMX5 | 383 km | 2025 | ✅ 运营中 |  |
| Southeast Asia-Japan Cable 2 (SJC2) | 10,500 km | 2025 | ✅ 运营中 |  |
| Q&E North | 112 km | 2025 | ✅ 运营中 |  |
| Norte Conectado (Infovia 03) | 600 km | 2025 | ✅ 运营中 |  |
| Lake Tanganyika | 370 km | 2025 | ✅ 运营中 |  |
| JUNO | 11,710 km | 2025 | ✅ 运营中 |  |
| Ithaafushi-Maafushi-Hulhumale | None | 2025 | ✅ 运营中 |  |
| Firmina | 14,517 km | 2025 | ✅ 运营中 |  |
| Farewell-Change-Fogo | 16 km | 2025 | ✅ 运营中 |  |
| Echo | 17,184 km | 2025 | ✅ 运营中 |  |
| Daito Loop | 18 km | 2025 | ✅ 运营中 |  |
| Coral Bridge | None | 2025 | ✅ 运营中 |  |
| Bifrost | 19,888 km | 2025 | ✅ 运营中 |  |
| Apricot | 11,972 km | 2025 | ✅ 运营中 |  |
| Apollo East and West | 670 km | 2025 | ✅ 运营中 |  |
| Airraq | 840 km | 2025 | ✅ 运营中 |  |
| SEALink South | 159 km | 2024 | ✅ 运营中 |  |
| Piano Isole Minori | 830 km | 2024 | ✅ 运营中 |  |
| MIST | 8,100 km | 2024 | ✅ 运营中 |  |
| Kochi-Lakshadweep Islands (KLI-SOFC) | 1,989 km | 2024 | ✅ 运营中 |  |
| Kangaroo Island 2 | None | 2024 | ✅ 运营中 |  |
| Isle Au Haut Cable | 10 km | 2024 | ✅ 运营中 |  |
| India Asia Xpress (IAX) | 5,791 km | 2024 | ✅ 运营中 |  |
| Iceni | None | 2024 | ✅ 运营中 |  |
| EAUFON 2 | 675 km | 2024 | ✅ 运营中 |  |
| Domestic Submarine Cable of Maldives (DSCoM) | 286 km | 2024 | ✅ 运营中 |  |
| Deep Blue One | 2,250 km | 2024 | ✅ 运营中 |  |
| Connected Coast | None | 2024 | ✅ 运营中 |  |
| Challenger One Bermuda | None | 2024 | ✅ 运营中 |  |
| Biznet Nusantara Cable System-1 (BNCS-1) | 105 km | 2024 | ✅ 运营中 |  |
| Aurora | 500 km | 2024 | ✅ 运营中 |  |
| Asia Direct Cable (ADC) | 9,988 km | 2024 | ✅ 运营中 |  |
| 2Africa | 45,000 km | 2024 | ✅ 运营中 |  |
| YUI | 720 km | 2023 | ✅ 运营中 |  |
| Unitel North Submarine Cable (UNSC) | 1,145 km | 2023 | ✅ 运营中 |  |
| Ultramar GE | 263 km | 2023 | ✅ 运营中 |  |
| UMO | 2,227 km | 2023 | ✅ 运营中 |  |
| Trans Adriatic Express (TAE) | 106 km | 2023 | ✅ 运营中 |  |
| Topaz | None | 2023 | ✅ 运营中 |  |
| Tokelau Submarine Cable | 250 km | 2023 | ✅ 运营中 |  |
| Tautira-Teahupo'o | 38 km | 2023 | ✅ 运营中 |  |
| TKO Connect | 6 km | 2023 | ✅ 运营中 |  |
| T3 | 3,200 km | 2023 | ✅ 运营中 |  |
| Senegal Horn of Africa Regional Express (SHARE) Cable | 720 km | 2023 | ✅ 运营中 |  |
| Saudi Vision | 1,071 km | 2023 | ✅ 运营中 |  |
| SEALink | 345 km | 2023 | ✅ 运营中 |  |
| Red2Med | 420 km | 2023 | ✅ 运营中 |  |
| R100 North | 224 km | 2023 | ✅ 运营中 |  |
| Philippine Domestic Submarine Cable Network (PDSCN) | 2,500 km | 2023 | ✅ 运营中 |  |
| Patara-2 | 1,200 km | 2023 | ✅ 运营中 |  |
| Norte Conectado (Infovia 01) | 1,100 km | 2023 | ✅ 运营中 |  |
| Norfest | 749 km | 2023 | ✅ 运营中 |  |
| Natitua Sud | 820 km | 2023 | ✅ 运营中 |  |
| Mercator | None | 2023 | ✅ 运营中 |  |
| Medloop | 1,360 km | 2023 | ✅ 运营中 |  |
| Jeju-Udo | 3 km | 2023 | ✅ 运营中 |  |
| Jalapati | 45 km | 2023 | ✅ 运营中 |  |
| Ionian | 320 km | 2023 | ✅ 运营中 |  |
| IRIS | 1,770 km | 2023 | ✅ 运营中 |  |
| Hokkaido-Akita Cable | 770 km | 2023 | ✅ 运营中 |  |
| Equiano | 15,000 km | 2023 | ✅ 运营中 |  |
| Darwin-Jakarta-Singapore Cable (DJSC) | 1,000 km | 2023 | ✅ 运营中 |  |
| Blue | 5,055 km | 2023 | ✅ 运营中 |  |
| Amitie | 6,792 km | 2023 | ✅ 运营中 |  |
| ARIMAO | 2,470 km | 2023 | ✅ 运营中 |  |
| Zeus | None | 2022 | ✅ 运营中 |  |
| Yuza-Tobishima | 31 km | 2022 | ✅ 运营中 |  |
| Thetis | 660 km | 2022 | ✅ 运营中 |  |
| Submarine Cable in the Philippines (SCiP) | 1,638 km | 2022 | ✅ 运营中 |  |
| Southern Cross NEXT | 13,700 km | 2022 | ✅ 运营中 |  |
| Scotland-Northern Ireland 4 | 85 km | 2022 | ✅ 运营中 |  |
| Scotland-Northern Ireland 3 | 42 km | 2022 | ✅ 运营中 |  |
| Polar Express | 12,650 km | 2022 | ✅ 运营中 |  |
| Petropavlovsk-Kamchatsky - Anadyr | 2,173 km | 2022 | ✅ 运营中 |  |
| Pacific Light Cable Network (PLCN) | 11,806 km | 2022 | ✅ 运营中 |  |
| PEACE Cable | 25,000 km | 2022 | ✅ 运营中 |  |
| Oman Australia Cable (OAC) | 11,000 km | 2022 | ✅ 运营中 |  |
| Norte Conectado (Infovia 00) | 770 km | 2022 | ✅ 运营中 |  |
| N0r5ke Viking | 810 km | 2022 | ✅ 运营中 |  |
| Kitadaito Island | 410 km | 2022 | ✅ 运营中 |  |
| Hronn | 270 km | 2022 | ✅ 运营中 |  |
| Havsil | 120 km | 2022 | ✅ 运营中 |  |
| Havhingsten/North Sea Connect (NSC) | 661 km | 2022 | ✅ 运营中 |  |
| Havhingsten/CeltixConnect-2 (CC-2) | 301 km | 2022 | ✅ 运营中 |  |
| Groix 4 | 7 km | 2022 | ✅ 运营中 |  |
| Grace Hopper | 7,191 km | 2022 | ✅ 运营中 |  |
| Gondwana-2/Picot-2 | 1,515 km | 2022 | ✅ 运营中 |  |
| EAUFON 1 | 1,175 km | 2022 | ✅ 运营中 |  |
| Awashima-Murakami | 66 km | 2022 | ✅ 运营中 |  |
| AU-Aleutian | 1,491 km | 2022 | ✅ 运营中 |  |
| South Pacific Cable System (SPCS)/Mistral | 7,300 km | 2021 | ✅ 运营中 |  |
| Scylla | 204 km | 2021 | ✅ 运营中 |  |
| Sape-Labuan Bajo-Ende-Kupang | 474 km | 2021 | ✅ 运营中 |  |
| Projeto Amazônia Conectada (PAC 02) | 1,001 km | 2021 | ✅ 运营中 |  |
| NO-UK | 713 km | 2021 | ✅ 运营中 |  |
| Minoas East and West | 270 km | 2021 | ✅ 运营中 |  |
| Meltingpot Indianoceanic Submarine System (METISS) | 3,200 km | 2021 | ✅ 运营中 |  |
| Maroc Telecom West Africa | 8,600 km | 2021 | ✅ 运营中 |  |
| Maldives Sri Lanka Cable (MSC) | 863 km | 2021 | ✅ 运营中 |  |
| Malbec | 2,880 km | 2021 | ✅ 运营中 |  |
| Kingisepp-Kaliningrad System (Baltika) | 1,115 km | 2021 | ✅ 运营中 |  |
| Hainan to Hong Kong Express (H2HE) | 675 km | 2021 | ✅ 运营中 |  |
| EllaLink | 6,200 km | 2021 | ✅ 运营中 |  |
| Dunant | 6,400 km | 2021 | ✅ 运营中 |  |
| Djibouti Africa Regional Express 1 (DARE 1) | 4,854 km | 2021 | ✅ 运营中 |  |
| CrossChannel Fibre | 149 km | 2021 | ✅ 运营中 |  |
| Converge Domestic Submarine Cable Network (CDSCN) | 1,300 km | 2021 | ✅ 运营中 |  |
| Batam Sarawak Internet Cable System (BaSICS) | 762 km | 2021 | ✅ 运营中 |  |
| South Atlantic Inter Link (SAIL) | 5,800 km | 2020 | ✅ 运营中 |  |
| Skagenfiber West | 170 km | 2020 | ✅ 运营中 |  |
| Prat | 3,500 km | 2020 | ✅ 运营中 |  |
| Oran-Valencia (ORVAL) | 770 km | 2020 | ✅ 运营中 |  |
| Okinawa Cellular Cable | 760 km | 2020 | ✅ 运营中 |  |
| Manatua | 3,634 km | 2020 | ✅ 运营中 |  |
| Malta-Gozo Cable | 13 km | 2020 | ✅ 运营中 |  |
| Lake Albert 2 | 44 km | 2020 | ✅ 运营中 |  |
| KetchCan1 Submarine Fiber Cable System | 167 km | 2020 | ✅ 运营中 |  |
| Japan-Guam-Australia South (JGA-S) | 7,081 km | 2020 | ✅ 运营中 |  |
| Japan-Guam-Australia North (JGA-N) | 2,600 km | 2020 | ✅ 运营中 |  |
| JUPITER | 14,557 km | 2020 | ✅ 运营中 |  |
| Havfrue/AEC-2 | 7,650 km | 2020 | ✅ 运营中 |  |
| Guadeloupe Cable des Iles du Sud (GCIS) | 118 km | 2020 | ✅ 运营中 |  |
| Fibra Optica al Pacífico | 1,180 km | 2020 | ✅ 运营中 |  |
| Fibra Optica Austral | 2,800 km | 2020 | ✅ 运营中 |  |
| Eviny Digital | 210 km | 2020 | ✅ 运营中 |  |
| DOS CONTINENTES l & ll | 95 km | 2020 | ✅ 运营中 |  |
| Cyclades B | 52 km | 2020 | ✅ 运营中 |  |
| Curie | 10,476 km | 2020 | ✅ 运营中 |  |
| Coral Sea Cable System (CS²) | 4,700 km | 2020 | ✅ 运营中 |  |
| Cook Strait | 40 km | 2020 | ✅ 运营中 |  |
| Chennai-Andaman & Nicobar Islands Cable (CANI) | 2,300 km | 2020 | ✅ 运营中 |  |
| X-Link Submarine Cable | 775 km | 2019 | ✅ 运营中 |  |
| Vancouver-Bowen Island-Vancouver Island | 75 km | 2019 | ✅ 运营中 |  |
| Tanjung Pandan-Sungai Kakap | 348 km | 2019 | ✅ 运营中 |  |
| Sovetskaya Gavan-Uglegorsk | 127 km | 2019 | ✅ 运营中 |  |
| Sorsogon-Samar Submarine Fiber Optical Interconnection Project (SSSFOIP) | 21 km | 2019 | ✅ 运营中 |  |
| Sakhalin-Kuril Islands Cable | 940 km | 2019 | ✅ 运营中 |  |
| Rockabill | 221 km | 2019 | ✅ 运营中 |  |
| Palapa Ring East | 6,300 km | 2019 | ✅ 运营中 |  |
| Padang-Tua Pejat | 160 km | 2019 | ✅ 运营中 |  |
| PASULI | 40 km | 2019 | ✅ 运营中 |  |
| Mauritius and Rodrigues Submarine Cable System (MARS) | 677 km | 2019 | ✅ 运营中 |  |
| Lake Albert 1 | 51 km | 2019 | ✅ 运营中 |  |
| Kupang-Alor Cable Systems | 273 km | 2019 | ✅ 运营中 |  |
| Kumul Domestic Submarine Cable System | 5,457 km | 2019 | ✅ 运营中 |  |
| Kanawa | 1,746 km | 2019 | ✅ 运营中 |  |
| INDIGO-West | 4,600 km | 2019 | ✅ 运营中 |  |
| INDIGO-Central | 4,850 km | 2019 | ✅ 运营中 |  |
| Gulf of California Cable | 250 km | 2019 | ✅ 运营中 |  |
| GlobalConnect 6 (GC6) | None | 2019 | ✅ 运营中 |  |
| GTMO-PR | 1,400 km | 2019 | ✅ 运营中 |  |
| FLY-LION3 | 400 km | 2019 | ✅ 运营中 |  |
| Eastern Light Sweden-Finland I | None | 2019 | ✅ 运营中 |  |
| E-FINEST | None | 2019 | ✅ 运营中 |  |
| Denpasar-Waingapu Cable Systems | 814 km | 2019 | ✅ 运营中 |  |
| DAMAI Cable System | 575 km | 2019 | ✅ 运营中 |  |
| Crosslake Fibre | 59 km | 2019 | ✅ 运营中 |  |
| Chuuk-Pohnpei Cable | 1,200 km | 2019 | ✅ 运营中 |  |
| Caribbean Regional Communications Infrastructure Program (CARCIP) | 225 km | 2019 | ✅ 运营中 |  |
| COBRAcable | 304 km | 2019 | ✅ 运营中 |  |
| Besut-Perhentian Islands | 21 km | 2019 | ✅ 运营中 |  |
| 5 Villages 6 Islands | 355 km | 2019 | ✅ 运营中 |  |
| Tui-Samoa | 1,693 km | 2018 | ✅ 运营中 |  |
| Tonga Domestic Cable Extension (TDCE) | 410 km | 2018 | ✅ 运营中 |  |
| Tannat | 2,000 km | 2018 | ✅ 运营中 |  |
| St. Pierre and Miquelon Cable | 200 km | 2018 | ✅ 运营中 |  |
| South Atlantic Cable System (SACS) | 6,165 km | 2018 | ✅ 运营中 |  |
| Sir Abu Nu’ayr Cable | 84 km | 2018 | ✅ 运营中 |  |
| SEAX-1 | 250 km | 2018 | ✅ 运营中 |  |
| Rompin-Tioman Island | 75 km | 2018 | ✅ 运营中 |  |
| Palapa Ring West | 1,980 km | 2018 | ✅ 运营中 |  |
| Palapa Ring Middle | 2,100 km | 2018 | ✅ 运营中 |  |
| New Cross Pacific (NCP) Cable System | 13,618 km | 2018 | ✅ 运营中 |  |
| Natitua | 2,680 km | 2018 | ✅ 运营中 |  |
| MAREA | 6,605 km | 2018 | ✅ 运营中 |  |
| Lumut-Pangkor Island | 4 km | 2018 | ✅ 运营中 |  |
| Junior | 390 km | 2018 | ✅ 运营中 |  |
| Jakarta Surabaya Cable System (JAYABAYA) | 888 km | 2018 | ✅ 运营中 |  |
| Indonesia Global Gateway (IGG) System | 5,300 km | 2018 | ✅ 运营中 |  |
| Hawaiki | 14,000 km | 2018 | ✅ 运营中 |  |
| Cyclades A | 222 km | 2018 | ✅ 运营中 |  |
| Cowes-Fawley 2 | None | 2018 | ✅ 运营中 |  |
| BRUSA | 11,000 km | 2018 | ✅ 运营中 |  |
| Australia-Singapore Cable (ASC) | 4,600 km | 2018 | ✅ 运营中 |  |
| Tasman Global Access (TGA) Cable | 2,288 km | 2017 | ✅ 运营中 |  |
| Strategic Evolution Underwater Link (SEUL) | 24 km | 2017 | ✅ 运营中 |  |
| Sistem Kabel Rakyat 1Malaysia (SKR1M) | 3,800 km | 2017 | ✅ 运营中 |  |
| Seabras-1 | 10,800 km | 2017 | ✅ 运营中 |  |
| SEA-US | 14,500 km | 2017 | ✅ 运营中 |  |
| Quintillion Subsea Cable Network | 1,900 km | 2017 | ✅ 运营中 |  |
| Projeto Amazônia Conectada (PAC 01) | 800 km | 2017 | ✅ 运营中 |  |
| Okinawa Remote Islands | 915 km | 2017 | ✅ 运营中 |  |
| Monet | 10,556 km | 2017 | ✅ 运营中 |  |
| Malaysia-Cambodia-Thailand (MCT) Cable | 1,300 km | 2017 | ✅ 运营中 |  |
| Labuan-Brunei Submarine Cable | 52 km | 2017 | ✅ 运营中 |  |
| Gulf2Africa (G2A) | 1,500 km | 2017 | ✅ 运营中 |  |
| Greenland Connect North | 680 km | 2017 | ✅ 运营中 |  |
| Energy Bridge Cable | 13 km | 2017 | ✅ 运营中 |  |
| Ceiba-2 | 290 km | 2017 | ✅ 运营中 |  |
| Atisa | 279 km | 2017 | ✅ 运营中 |  |
| Asia Africa Europe-1 (AAE-1) | 25,000 km | 2017 | ✅ 运营中 |  |
| sea2shore | 32 km | 2016 | ✅ 运营中 |  |
| Ulleung-Mainland 2 | 164 km | 2016 | ✅ 运营中 |  |
| SeaMeWe-5 | 20,000 km | 2016 | ✅ 运营中 |  |
| Pencan-9 | 1,398 km | 2016 | ✅ 运营中 |  |
| North-West Cable System | 2,100 km | 2016 | ✅ 运营中 |  |
| NordBalt | 400 km | 2016 | ✅ 运营中 |  |
| Nationwide Submarine Cable Ooredoo Maldives (NaSCOM) | 1,136 km | 2016 | ✅ 运营中 |  |
| Lynn Canal Fiber | 138 km | 2016 | ✅ 运营中 |  |
| GTMO-1 | 1,528 km | 2016 | ✅ 运营中 |  |
| Far East Submarine Cable System | 1,855 km | 2016 | ✅ 运营中 |  |
| FASTER | 11,629 km | 2016 | ✅ 运营中 |  |
| C-Lion1 | 1,172 km | 2016 | ✅ 运营中 |  |
| Bodo-Rost Cable | 109 km | 2016 | ✅ 运营中 |  |
| Bay of Bengal Gateway (BBG) | 8,100 km | 2016 | ✅ 运营中 |  |
| BALOK | 60 km | 2016 | ✅ 运营中 |  |
| Avassa | 260 km | 2016 | ✅ 运营中 |  |
| Asia Pacific Gateway (APG) | 10,400 km | 2016 | ✅ 运营中 |  |
| AEC-1 | 5,521 km | 2016 | ✅ 运营中 |  |
| Zayo Festoon | None | 2015 | ✅ 运营中 |  |
| TT1 | 44 km | 2015 | ✅ 运营中 |  |
| Segunda FOS Canal de Chacao | 40 km | 2015 | ✅ 运营中 |  |
| SMPCS Packet-2 | 3,498 km | 2015 | ✅ 运营中 |  |
| SMPCS Packet-1 | 3,156 km | 2015 | ✅ 运营中 |  |
| Portsmouth-Ryde 11 | None | 2015 | ✅ 运营中 |  |
| Portsmouth-Ryde 10 | None | 2015 | ✅ 运营中 |  |
| Pacific Caribbean Cable System (PCCS) | 6,163 km | 2015 | ✅ 运营中 |  |
| Nigeria Cameroon Submarine Cable System (NCSCS) | 1,100 km | 2015 | ✅ 运营中 |  |
| Malta-Italy Interconnector | 95 km | 2015 | ✅ 运营中 |  |
| Luwuk Tutuyan Cable System (LTCS) | 446 km | 2015 | ✅ 运营中 |  |
| Longyearbyen-Ny-Ålesund | 540 km | 2015 | ✅ 运营中 |  |
| FOS Quellon-Chacabuco | 350 km | 2015 | ✅ 运营中 |  |
| EXA Express | 4,600 km | 2015 | ✅ 运营中 |  |
| Tarakan Selor Cable System (TSCS) | 83 km | 2014 | ✅ 运营中 |  |
| Sumatera Bangka Cable System (SBCS) | 57 km | 2014 | ✅ 运营中 |  |
| Skagerrak 4 | 137 km | 2014 | ✅ 运营中 |  |
| Roquetas-Melilla (CAM) | 181 km | 2014 | ✅ 运营中 |  |
| Palawan-Iloilo Cable System | 300 km | 2014 | ✅ 运营中 |  |
| POSEIDON | 800 km | 2014 | ✅ 运营中 |  |
| PNG LNG | 200 km | 2014 | ✅ 运营中 |  |
| Middle East North Africa (MENA) Cable System/Gulf Bridge International | 8,000 km | 2014 | ✅ 运营中 |  |
| Kerch Strait Cable | 46 km | 2014 | ✅ 运营中 |  |
| Jambi-Batam Cable System (JIBA) | 267 km | 2014 | ✅ 运营中 |  |
| Isles of Scilly Cable | None | 2014 | ✅ 运营中 |  |
| Interchange Cable Network 1 (ICN1) | 1,259 km | 2014 | ✅ 运营中 |  |
| Flores-Corvo Cable System | 685 km | 2014 | ✅ 运营中 |  |
| Didon | 170 km | 2014 | ✅ 运营中 |  |
| BT Highlands and Islands Submarine Cable System | 402 km | 2014 | ✅ 运营中 |  |
| America Movil Submarine Cable System-1 (AMX-1) | 17,800 km | 2014 | ✅ 运营中 |  |
| Tonga Cable | 827 km | 2013 | ✅ 运营中 |  |
| Taiwan Strait Express-1 (TSE-1) | 260 km | 2013 | ✅ 运营中 |  |
| Taiwan Penghu Kinmen Matsu No.3 (TPKM3) | 510 km | 2013 | ✅ 运营中 |  |
| Southeast Asia-Japan Cable (SJC) | 8,900 km | 2013 | ✅ 运营中 |  |
| Silphium | 425 km | 2013 | ✅ 运营中 |  |
| Saba, Statia Cable System (SSCS) | 198 km | 2013 | ✅ 运营中 |  |
| OMRAN/EPEG | 600 km | 2013 | ✅ 运营中 |  |
| Lazaro Cardenas-Manzanillo Santiago Submarine Cable System (LCMSSCS) | 322 km | 2013 | ✅ 运营中 |  |
| Java Bali Cable System (JBCS) | None | 2013 | ✅ 运营中 |  |
| Jakarta-Bangka-Batam-Singapore (B2JS) | 759 km | 2013 | ✅ 运营中 |  |
| Guam Okinawa Kyushu Incheon (GOKI) | 4,244 km | 2013 | ✅ 运营中 |  |
| CAT Submarine Network (CSN) | 1,240 km | 2013 | ✅ 运营中 |  |
| Boracay-Palawan Submarine Cable System (BPSCS) | 332 km | 2013 | ✅ 运营中 |  |
| West Africa Cable System (WACS) | 14,530 km | 2012 | ✅ 运营中 |  |
| Tata TGN-Gulf | 4,031 km | 2012 | ✅ 运营中 |  |
| TERRA SW | None | 2012 | ✅ 运营中 |  |
| Seychelles to East Africa System (SEAS) | 1,930 km | 2012 | ✅ 运营中 |  |
| Pishgaman Oman Iran (POI) Network | 400 km | 2012 | ✅ 运营中 |  |
| Lower Indian Ocean Network 2 (LION2) | 2,700 km | 2012 | ✅ 运营中 |  |
| Libreville-Port Gentil Cable | 198 km | 2012 | ✅ 运营中 |  |
| Jonah | 2,297 km | 2012 | ✅ 运营中 |  |
| Jakarta-Bangka-Bintan-Batam-Singapore (B3JS) | 1,031 km | 2012 | ✅ 运营中 |  |
| Gulf Bridge International Cable System/Middle East North Africa Cable System (GBICS/MENA) | 5,270 km | 2012 | ✅ 运营中 |  |
| Geo-Eirgrid | 187 km | 2012 | ✅ 运营中 |  |
| Exelera North | 345 km | 2012 | ✅ 运营中 |  |
| Emerald Bridge Fibres | 120 km | 2012 | ✅ 运营中 |  |
| Dhiraagu Cable Network | 1,253 km | 2012 | ✅ 运营中 |  |
| Cross-Straits Cable Network (CSCN) | 21 km | 2012 | ✅ 运营中 |  |
| CeltixConnect-1 (CC-1) | 131 km | 2012 | ✅ 运营中 |  |
| Asia Submarine-cable Express (ASE)/Cahaya Malaysia | 8,148 km | 2012 | ✅ 运营中 |  |
| Alaska United Turnagain Arm (AUTA) | 53 km | 2012 | ✅ 运营中 |  |
| Africa Coast to Europe (ACE) | 17,000 km | 2012 | ✅ 运营中 |  |
| ARSAT Submarine Fiber Optic Cable | 40 km | 2012 | ✅ 运营中 |  |
| ALBA-1 | 1,860 km | 2012 | ✅ 运营中 |  |
| Turcyos-2 | 213 km | 2011 | ✅ 运营中 |  |
| TE North/TGN-Eurasia/SEACOM/Alexandros/Medex | 3,634 km | 2011 | ✅ 运营中 |  |
| Saudi Arabia-Sudan-2 (SAS-2) | 330 km | 2011 | ✅ 运营中 |  |
| Romulo | 237 km | 2011 | ✅ 运营中 |  |
| Pencan-8 | 1,400 km | 2011 | ✅ 运营中 |  |
| Ogasawara Cable Network | 1,038 km | 2011 | ✅ 运营中 |  |
| Minamidaito Island | 410 km | 2011 | ✅ 运营中 |  |
| Mataram Kupang Cable System (MKCS) | 1,318 km | 2011 | ✅ 运营中 |  |
| JAVALI | None | 2011 | ✅ 运营中 |  |
| Hokkaido-Rebun-Rishiri | 64 km | 2011 | ✅ 运营中 |  |
| Hawk | 3,400 km | 2011 | ✅ 运营中 |  |
| Groote Eylandt | 95 km | 2011 | ✅ 运营中 |  |
| FISH North | 90 km | 2011 | ✅ 运营中 |  |
| Europe India Gateway (EIG) | 15,000 km | 2011 | ✅ 运营中 |  |
| Energinet Lyngsa-Laeso | None | 2011 | ✅ 运营中 |  |
| Energinet Laeso-Varberg | None | 2011 | ✅ 运营中 |  |
| East-West Cable (EWC) | 1,705 km | 2011 | ✅ 运营中 |  |
| Ceiba-1 | 287 km | 2011 | ✅ 运营中 |  |
| Canalink | 1,835 km | 2011 | ✅ 运营中 |  |
| Cabo Verde Telecom Domestic Submarine Cable Phase 3 | None | 2011 | ✅ 运营中 |  |
| Bicentenario | 250 km | 2011 | ✅ 运营中 |  |
| Unity | 9,620 km | 2010 | ✅ 运营中 |  |
| Tverrlinken | None | 2010 | ✅ 运营中 |  |
| Tobrok-Emasaed Cable System | 178 km | 2010 | ✅ 运营中 |  |
| Suriname-Guyana Submarine Cable System (SG-SCS) | 1,249 km | 2010 | ✅ 运营中 |  |
| San Andres Isla Tolu Submarine Cable (SAIT) | 826 km | 2010 | ✅ 运营中 |  |
| PGASCOM | 264 km | 2010 | ✅ 运营中 |  |
| Mishima Village | 192 km | 2010 | ✅ 运营中 |  |
| MainOne | 7,000 km | 2010 | ✅ 运营中 |  |
| Konstanz-Meersburg | 5 km | 2010 | ✅ 运营中 |  |
| JaKa2LaDeMa | 1,700 km | 2010 | ✅ 运营中 |  |
| IMEWE | 12,091 km | 2010 | ✅ 运营中 |  |
| Honotua | 4,805 km | 2010 | ✅ 运营中 |  |
| HANTRU1 Cable System | 2,917 km | 2010 | ✅ 运营中 |  |
| Glo-1 | 9,800 km | 2010 | ✅ 运营中 |  |
| Eastern Africa Submarine System (EASSy) | 10,500 km | 2010 | ✅ 运营中 |  |
| Comoros Domestic Cable System | None | 2010 | ✅ 运营中 |  |
| The East African Marine System (TEAMS) | 5,054 km | 2009 | ✅ 运营中 |  |
| Tata TGN-Intra Asia (TGN-IA) | 6,700 km | 2009 | ✅ 运营中 |  |
| Samoa-American Samoa (SAS) | 250 km | 2009 | ✅ 运营中 |  |
| SEACOM/Tata TGN-Eurasia | 15,000 km | 2009 | ✅ 运营中 |  |
| Paniolo Cable Network | 576 km | 2009 | ✅ 运营中 |  |
| PIPE Pacific Cable-1 (PPC-1) | 6,900 km | 2009 | ✅ 运营中 |  |
| Melita 1 | 97 km | 2009 | ✅ 运营中 |  |
| Lower Indian Ocean Network (LION) | 1,060 km | 2009 | ✅ 运营中 |  |
| JAKABARE | 1,330 km | 2009 | ✅ 运营中 |  |
| HANNIBAL System | 178 km | 2009 | ✅ 运营中 |  |
| Greenland Connect | 4,580 km | 2009 | ✅ 运营中 |  |
| DANICE | 2,304 km | 2009 | ✅ 运营中 |  |
| Caribbean-Bermuda U.S. (CBUS) | 1,700 km | 2009 | ✅ 运营中 |  |
| Batam Singapore Cable System (BSCS) | 73 km | 2009 | ✅ 运营中 |  |
| Batam Dumai Melaka (BDM) | 353 km | 2009 | ✅ 运营中 |  |
| Asia-America Gateway (AAG) Cable System | 20,000 km | 2009 | ✅ 运营中 |  |
| ACS Alaska-Oregon Network (AKORN) | 3,000 km | 2009 | ✅ 运营中 |  |
| Västervik-Visby | None | 2008 | ✅ 运营中 |  |
| Vodafone Greece Domestic | 92 km | 2008 | ✅ 运营中 |  |
| Trans-Pacific Express (TPE) Cable System | 17,968 km | 2008 | ✅ 运营中 |  |
| Telstra Endeavour | 9,125 km | 2008 | ✅ 运营中 |  |
| STO-HEL-One | 560 km | 2008 | ✅ 运营中 |  |
| SJJK | 543 km | 2008 | ✅ 运营中 |  |
| SHEFA-2 | 1,000 km | 2008 | ✅ 运营中 |  |
| S-U-B Cable System | 2,009 km | 2008 | ✅ 运营中 |  |
| Russia-Japan Cable Network (RJCN) | 1,800 km | 2008 | ✅ 运营中 |  |
| Picot-1 | None | 2008 | ✅ 运营中 |  |
| Persona | 800 km | 2008 | ✅ 运营中 |  |
| Oskarshamn-Visby | None | 2008 | ✅ 运营中 |  |
| Northern Lights | 67 km | 2008 | ✅ 运营中 |  |
| Moratelindo International Cable System-1 (MIC-1) | 70 km | 2008 | ✅ 运营中 |  |
| Matrix Cable System | 1,055 km | 2008 | ✅ 运营中 |  |
| Hokkaido-Sakhalin Cable System (HSCS) | 570 km | 2008 | ✅ 运营中 |  |
| Hachijojima-Mainland | None | 2008 | ✅ 运营中 |  |
| Gulf of Mexico Fiber Optic Network | 1,200 km | 2008 | ✅ 运营中 |  |
| Gondwana-1 | 2,151 km | 2008 | ✅ 运营中 |  |
| GO-1 Mediterranean Cable System | 290 km | 2008 | ✅ 运营中 |  |
| Colombia-Florida Express (CFX-1) | 2,438 km | 2008 | ✅ 运营中 |  |
| Channel Islands-9 Liberty Submarine Cable | None | 2008 | ✅ 运营中 |  |
| Caucasus Cable System | 1,200 km | 2008 | ✅ 运营中 |  |
| Alaska United Southeast (AU-SE) | 626 km | 2008 | ✅ 运营中 |  |
| Sovetskaya Gavan-Ilyinskoye | 214 km | 2007 | ✅ 运营中 |  |
| Ruppione-Isolella | 62 km | 2007 | ✅ 运营中 |  |
| Polar Circle Cable | 1,004 km | 2007 | ✅ 运营中 |  |
| Konstanz-Friedrichshafen | 26 km | 2007 | ✅ 运营中 |  |
| Kodiak Kenai Fiber Link (KKFL) | 966 km | 2007 | ✅ 运营中 |  |
| Jerry Newton | 88 km | 2007 | ✅ 运营中 |  |
| Ixchel | 20 km | 2007 | ✅ 运营中 |  |
| High-capacity Undersea Guernsey Optical-fibre (HUGO) | 425 km | 2007 | ✅ 运营中 |  |
| Gemini Bermuda | 1,501 km | 2007 | ✅ 运营中 |  |
| EC Link | 1,078 km | 2007 | ✅ 运营中 |  |
| E-LLAN | None | 2007 | ✅ 运营中 |  |
| Dhiraagu-SLT Submarine Cable Network | 850 km | 2007 | ✅ 运营中 |  |
| Batam-Rengit Cable System (BRCS) | 64 km | 2007 | ✅ 运营中 |  |
| Atlas Offshore | 1,634 km | 2007 | ✅ 运营中 |  |
| Transworld (TW1) | 1,300 km | 2006 | ✅ 运营中 |  |
| Southern Caribbean Fiber | 3,000 km | 2006 | ✅ 运营中 |  |
| SARCO | None | 2006 | ✅ 运营中 |  |
| Java-Kalimantan-Sulawesi (JAKASUSI) | 1,100 km | 2006 | ✅ 运营中 |  |
| JaSuKa | None | 2006 | ✅ 运营中 |  |
| GlobalConnect-KPN | 43 km | 2006 | ✅ 运营中 |  |
| GlobalConnect 3 (GC3) | 19 km | 2006 | ✅ 运营中 |  |
| Global Caribbean Network (GCN) | 890 km | 2006 | ✅ 运营中 |  |
| Fibralink | 1,102 km | 2006 | ✅ 运营中 |  |
| FALCON | 10,300 km | 2006 | ✅ 运营中 |  |
| Bharat Lanka Cable System | 325 km | 2006 | ✅ 运营中 |  |
| Bahamas Domestic Submarine Network (BDSNi) | 2,735 km | 2006 | ✅ 运营中 |  |
| Sweden-Latvia | 391 km | 2005 | ✅ 运营中 |  |
| SeaMeWe-4 | 20,000 km | 2005 | ✅ 运营中 |  |
| Red Hook-Little Saint James | 5 km | 2005 | ✅ 运营中 |  |
| Med Cable Network | 1,300 km | 2005 | ✅ 运营中 |  |
| Link 5 Phase-2 | 365 km | 2005 | ✅ 运营中 |  |
| Link 4 Phase-2 | 300 km | 2005 | ✅ 运营中 |  |
| Link 3 Phase-2 | 342 km | 2005 | ✅ 运营中 |  |
| Link 2 Phase-2 | 221 km | 2005 | ✅ 运营中 |  |
| Link 1 Phase-2 | 94 km | 2005 | ✅ 运营中 |  |
| Kuwait-Iran | 380 km | 2005 | ✅ 运营中 |  |
| Janna | 634 km | 2005 | ✅ 运营中 |  |
| Grand Bahama Bimini Submarine Cable | 117 km | 2005 | ✅ 运营中 |  |
| Dumai-Melaka Cable System (DMCS) | 159 km | 2005 | ✅ 运营中 |  |
| COGIM | 438 km | 2005 | ✅ 运营中 |  |
| Basslink | 298 km | 2005 | ✅ 运营中 |  |
| Tata TGN-Tata Indicom | 3,175 km | 2004 | ✅ 运营中 |  |
| Svalbard Undersea Cable System | 2,714 km | 2004 | ✅ 运营中 |  |
| Sint Maarten Puerto Rico Network One (SMPR-1) | 375 km | 2004 | ✅ 运营中 |  |
| Qatar-U.A.E. Submarine Cable System | 100 km | 2004 | ✅ 运营中 |  |
| Okinawa-Miyakojima-Ishigaki | 467 km | 2004 | ✅ 运营中 |  |
| OTEGLOBE Kokkini-Bari | 700 km | 2004 | ✅ 运营中 |  |
| Link 2 Phase-1 | 281 km | 2004 | ✅ 运营中 |  |
| INGRID | 64 km | 2004 | ✅ 运营中 |  |
| FARICE-1 | 1,205 km | 2004 | ✅ 运营中 |  |
| Epic Malta-Sicily Cable System (EMSCS) | 260 km | 2004 | ✅ 运营中 |  |
| East-West Submarine Cable System | 950 km | 2004 | ✅ 运营中 |  |
| Alaska United West (AU-West) | 2,485 km | 2004 | ✅ 运营中 |  |
| Thailand-Indonesia-Singapore (TIS) | 968 km | 2003 | ✅ 运营中 |  |
| Saudi Arabia-Sudan-1 (SAS-1) | 333 km | 2003 | ✅ 运营中 |  |
| Link 3 Phase-1 | 275 km | 2003 | ✅ 运营中 |  |
| Link 1 Phase-1 | 368 km | 2003 | ✅ 运营中 |  |
| Cross Sound Cable | 40 km | 2003 | ✅ 运营中 |  |
| CAM Ring | 1,120 km | 2003 | ✅ 运营中 |  |
| Bass Strait-2 | 239 km | 2003 | ✅ 运营中 |  |
| Apollo | 13,000 km | 2003 | ✅ 运营中 |  |
| i2i Cable Network (i2icn) | 3,200 km | 2002 | ✅ 运营中 |  |
| Tata TGN-Western Europe | 3,578 km | 2002 | ✅ 运营中 |  |
| Tata TGN-Pacific | 22,300 km | 2002 | ✅ 运营中 |  |
| Subcan Link 2 | 136 km | 2002 | ✅ 运营中 |  |
| Subcan Link 1 | 143 km | 2002 | ✅ 运营中 |  |
| SAT-3/WASC | 14,350 km | 2002 | ✅ 运营中 |  |
| SAFE | 13,500 km | 2002 | ✅ 运营中 |  |
| Muroran-Hachinohe | 280 km | 2002 | ✅ 运营中 |  |
| Korea-Japan Cable Network (KJCN) | 500 km | 2002 | ✅ 运营中 |  |
| EAC-C2C | 36,500 km | 2002 | ✅ 运营中 |  |
| Cabo Verde Telecom Domestic Submarine Cable Phase 2 | None | 2002 | ✅ 运营中 |  |
| Alpal-2 | 312 km | 2002 | ✅ 运营中 |  |
| Thailand Domestic Submarine Cable Network (TDSCN) | 884 km | 2001 | ✅ 运营中 |  |
| Tata TGN-Atlantic South | None | 2001 | ✅ 运营中 |  |
| South America-1 (SAm-1) | 25,000 km | 2001 | ✅ 运营中 |  |
| Nelson-Levin | 212 km | 2001 | ✅ 运营中 |  |
| MedNautilus Submarine System | 7,000 km | 2001 | ✅ 运营中 |  |
| Kattegat 2 | 75 km | 2001 | ✅ 运营中 |  |
| GlobalConnect 2 (GC2) | 95 km | 2001 | ✅ 运营中 |  |
| FLAG North Asia Loop/REACH North Asia Loop | 9,504 km | 2001 | ✅ 运营中 |  |
| FLAG Atlantic-1 (FA-1) | 14,500 km | 2001 | ✅ 运营中 |  |
| EXA North and South | 12,200 km | 2001 | ✅ 运营中 |  |
| CHI | 3,932 km | 2001 | ✅ 运营中 |  |
| Balalink | 274 km | 2001 | ✅ 运营中 |  |
| Bahamas Internet Cable System (BICS) | 1,100 km | 2001 | ✅ 运营中 |  |
| Australia-Japan Cable (AJC) | 12,700 km | 2001 | ✅ 运营中 |  |
| Aqualink | None | 2001 | ✅ 运营中 |  |
| ARCOS | 8,704 km | 2001 | ✅ 运营中 |  |
| APCN-2 | 19,000 km | 2001 | ✅ 运营中 |  |
| Yellow | 7,001 km | 2000 | ✅ 运营中 |  |
| Tangerine | 112 km | 2000 | ✅ 运营中 |  |
| Taiwan Penghu Kinmen Matsu No.2 (TPKM2) | 467 km | 2000 | ✅ 运营中 |  |
| TRANSCAN-3 | 210 km | 2000 | ✅ 运营中 |  |
| Southern Cross Cable Network (SCCN) | 30,500 km | 2000 | ✅ 运营中 |  |
| South American Crossing (SAC) | 20,000 km | 2000 | ✅ 运营中 |  |
| Scandinavian Ring South | 21 km | 2000 | ✅ 运营中 |  |
| Scandinavian Ring North | 5 km | 2000 | ✅ 运营中 |  |
| Pan-American Crossing (PAC) | 10,000 km | 2000 | ✅ 运营中 |  |
| Pan European Crossing (UK-Ireland) | 495 km | 2000 | ✅ 运营中 |  |
| Mid-Atlantic Crossing (MAC) | 7,500 km | 2000 | ✅ 运营中 |  |
| Maya-1.2 | 2,386 km | 2000 | ✅ 运营中 |  |
| Manx-Northern Ireland | 59 km | 2000 | ✅ 运营中 |  |
| Lic-Lin-Lamp | 240 km | 2000 | ✅ 运营中 |  |
| Jeju-Mainland 3 | 236 km | 2000 | ✅ 运营中 |  |
| Israel Coasting 1 (IC-1) | 340 km | 2000 | ✅ 运营中 |  |
| GlobeNet | 23,500 km | 2000 | ✅ 运营中 |  |
| Germany-Denmark 3 | None | 2000 | ✅ 运营中 |  |
| Georgia-Russia | 433 km | 2000 | ✅ 运营中 |  |
| Finland Estonia Connection 2 (FEC-2) | None | 2000 | ✅ 运营中 |  |
| Finland Estonia Connection 1 (FEC-1) | None | 2000 | ✅ 运营中 |  |
| Fehmarn Bält | 20 km | 2000 | ✅ 运营中 |  |
| Elektra-GlobalConnect 1 (GC1) | 44 km | 2000 | ✅ 运营中 |  |
| ESAT-2 | 245 km | 2000 | ✅ 运营中 |  |
| Continente-Madeira | 1,179 km | 2000 | ✅ 运营中 |  |
| Baltic Sea Submarine Cable | 1,042 km | 2000 | ✅ 运营中 |  |
| BCS North - Phase 2 | 280 km | 2000 | ✅ 运营中 |  |
| Americas-II West | 217 km | 2000 | ✅ 运营中 |  |
| Whidbey Island-Seattle | 44 km | 1999 | ✅ 运营中 |  |
| Whidbey Island-Hat Island | 4 km | 1999 | ✅ 运营中 |  |
| Whidbey Island-Everett | 9 km | 1999 | ✅ 运营中 |  |
| Whidbey Island-Camano Island | 4 km | 1999 | ✅ 运营中 |  |
| Tenerife-Gran Canaria | 110 km | 1999 | ✅ 运营中 |  |
| Tampnet South | 1,751 km | 1999 | ✅ 运营中 |  |
| Tampnet North | 1,751 km | 1999 | ✅ 运营中 |  |
| Sunoque II | None | 1999 | ✅ 运营中 |  |
| Sunoque I | None | 1999 | ✅ 运营中 |  |
| Solas | 232 km | 1999 | ✅ 运营中 |  |
| Sirius South | 219 km | 1999 | ✅ 运营中 |  |
| Sirius North | 147 km | 1999 | ✅ 运营中 |  |
| PanAm South | 1,340 km | 1999 | ✅ 运营中 |  |
| Pan European Crossing (UK-Belgium) | 117 km | 1999 | ✅ 运营中 |  |
| Pacific Crossing-1 (PC-1) | 21,000 km | 1999 | ✅ 运营中 |  |
| NorthStar | 3,229 km | 1999 | ✅ 运营中 |  |
| Ningbo-Zhoushan Cable | 35 km | 1999 | ✅ 运营中 |  |
| National Digital Transmission Network (NDTN) | 1,400 km | 1999 | ✅ 运营中 |  |
| LFON (Libyan Fiber Optic Network) | 1,639 km | 1999 | ✅ 运营中 |  |
| Japan Information Highway (JIH) | 5,150 km | 1999 | ✅ 运营中 |  |
| Haikou-Beihai Cable | 198 km | 1999 | ✅ 运营中 |  |
| Concerto | 550 km | 1999 | ✅ 运营中 |  |
| Columbus-III Azores-Portugal | None | 1999 | ✅ 运营中 |  |
| Circe South | 115 km | 1999 | ✅ 运营中 |  |
| Circe North | 203 km | 1999 | ✅ 运营中 |  |
| CANDALTA | 110 km | 1999 | ✅ 运营中 |  |
| Amerigo Vespucci | 87 km | 1999 | ✅ 运营中 |  |
| AmeriCan-1 | 140 km | 1999 | ✅ 运营中 |  |
| Alonso de Ojeda | 122 km | 1999 | ✅ 运营中 |  |
| Alaska United East (AU-East) | 3,751 km | 1999 | ✅ 运营中 |  |
| Venezuelan Festoon | 1,200 km | 1998 | ✅ 运营中 |  |
| Taba-Aqaba | 13 km | 1998 | ✅ 运营中 |  |
| Sagres | 302 km | 1998 | ✅ 运营中 |  |
| Italy-Libya | 570 km | 1998 | ✅ 运营中 |  |
| Fiber Optic Gulf (FOG) | 1,300 km | 1998 | ✅ 运营中 |  |
| Farland North | 150 km | 1998 | ✅ 运营中 |  |
| Danica North | 25 km | 1998 | ✅ 运营中 |  |
| Dalian-Yantai Cable | 146 km | 1998 | ✅ 运营中 |  |
| BCS North - Phase 1 | 513 km | 1998 | ✅ 运营中 |  |
| Azores Fiber Optic System (AFOS) | 1,100 km | 1998 | ✅ 运营中 |  |
| Atlantic Crossing-1 (AC-1) | 14,301 km | 1998 | ✅ 运营中 |  |
| Ulysses 2 | None | 1997 | ✅ 运营中 |  |
| St. Thomas-St. Croix System | 183 km | 1997 | ✅ 运营中 |  |
| PLDT Domestic Fiber Optic Network (DFON) | 11,100 km | 1997 | ✅ 运营中 |  |
| Miyazaki-Okinawa Cable (MOC) | None | 1997 | ✅ 运营中 |  |
| Mariana-Guam Cable | 268 km | 1997 | ✅ 运营中 |  |
| KAFOS | 538 km | 1997 | ✅ 运营中 |  |
| Jamaica Submarine Cable Festoon System (JSCFS) | 342 km | 1997 | ✅ 运营中 |  |
| Italy-Albania | 240 km | 1997 | ✅ 运营中 |  |
| Hawaii Island Fibre Network (HIFN) | 529 km | 1997 | ✅ 运营中 |  |
| FEA | None | 1997 | ✅ 运营中 |  |
| Colombian Festoon | 400 km | 1997 | ✅ 运营中 |  |
| Cayman-Jamaica Fiber System (CJFS) | 1,197 km | 1997 | ✅ 运营中 |  |
| Calvi-St. Florent | 64 km | 1997 | ✅ 运营中 |  |
| Cabo Verde Telecom Domestic Submarine Cable Phase 1 | None | 1997 | ✅ 运营中 |  |
| Baltica | 437 km | 1997 | ✅ 运营中 |  |
| Bahamas 2 | 476 km | 1997 | ✅ 运营中 |  |
| BERYTAR | 134 km | 1997 | ✅ 运营中 |  |
| BCS East-West Interlink | 218 km | 1997 | ✅ 运营中 |  |
| Antillas 1 | 601 km | 1997 | ✅ 运营中 |  |
| Aletar | 787 km | 1997 | ✅ 运营中 |  |
| Îles d'Hyères Cable | 45 km | 1996 | ✅ 运营中 |  |
| ROMSAR 2 | None | 1996 | ✅ 运营中 |  |
| Jeju-Mainland 2 | 191 km | 1996 | ✅ 运营中 |  |
| Izu Islands Cable System | None | 1996 | ✅ 运营中 |  |
| Denmark-Sweden 18 | None | 1996 | ✅ 运营中 |  |
| Brazilian Festoon | 2,552 km | 1996 | ✅ 运营中 |  |
| BUGIO | 73 km | 1996 | ✅ 运营中 |  |
| Adria-1 | 440 km | 1996 | ✅ 运营中 |  |
| Unisur | 265 km | 1995 | ✅ 运营中 |  |
| UGARIT | 239 km | 1995 | ✅ 运营中 |  |
| Sweden-Estonia (EE-S 1) | 240 km | 1995 | ✅ 运营中 |  |
| Italy-Monaco | 162 km | 1995 | ✅ 运营中 |  |
| Italy-Greece 1 (IG-1) | 169 km | 1995 | ✅ 运营中 |  |
| Eastern Caribbean Fiber System (ECFS) | 1,335 km | 1995 | ✅ 运营中 |  |
| Corse-Continent 5 (CC5) | 299 km | 1995 | ✅ 运营中 |  |
| CADMOS | 230 km | 1995 | ✅ 运营中 |  |
| Bass Strait-1 | 241 km | 1995 | ✅ 运营中 |  |
| BCS East | 97 km | 1995 | ✅ 运营中 |  |
| Antigua-St.Kitts | 141 km | 1995 | ✅ 运营中 |  |
| APOCS 2 | None | 1995 | ✅ 运营中 |  |
| UK-Channel Islands-8 | 237 km | 1994 | ✅ 运营中 |  |
| UK-Channel Islands-7 | 124 km | 1994 | ✅ 运营中 |  |
| TEGOPA | 222 km | 1994 | ✅ 运营中 |  |
| Penbal-5 | 315 km | 1994 | ✅ 运营中 |  |
| Latvia-Sweden 1 (LV-SE 1) | 304 km | 1994 | ✅ 运营中 |  |
| Italy-Malta | 238 km | 1994 | ✅ 运营中 |  |
| Italy-Croatia | 230 km | 1994 | ✅ 运营中 |  |
| Hawaii Inter-Island Cable System (HICS) | 479 km | 1994 | ✅ 运营中 |  |
| Guernsey-Jersey-4 | 36 km | 1994 | ✅ 运营中 |  |
| GlobalConnect Denmark-Sweden | None | 1994 | ✅ 运营中 |  |
| Finland-Estonia 3 (EESF-3) | 104 km | 1994 | ✅ 运营中 |  |
| Est-Tet | 113 km | 1994 | ✅ 运营中 |  |
| Denmark-Sweden 17 | 11 km | 1994 | ✅ 运营中 |  |
| Columbus-II b | 2,068 km | 1994 | ✅ 运营中 |  |
| CANTAT-3 | 270 km | 1994 | ✅ 运营中 |  |
| Botnia | 93 km | 1994 | ✅ 运营中 |  |
| Americas-I North | 2,012 km | 1994 | ✅ 运营中 |  |
| Aden-Djibouti | 269 km | 1994 | ✅ 运营中 |  |
| Turcyos-1 | 110 km | 1993 | ✅ 运营中 |  |
| UAE-Iran | 170 km | 1992 | ✅ 运营中 |  |
| Taino-Carib | 187 km | 1992 | ✅ 运营中 |  |
| Lanis-3 | 122 km | 1992 | ✅ 运营中 |  |
| Lanis-2 | 67 km | 1992 | ✅ 运营中 |  |
| Lanis-1 | 113 km | 1992 | ✅ 运营中 |  |
| Finland-Estonia 2 (EESF-2) | 98 km | 1992 | ✅ 运营中 |  |
| Corse-Continent 4 (CC4) | 190 km | 1992 | ✅ 运营中 |  |
| Penbal-4 | 317 km | 1991 | ✅ 运营中 |  |
| APOCS 1 | None | 1991 | ✅ 运营中 |  |
| TRANSCAN-2 | 238 km | 1990 | ✅ 运营中 |  |
| BT-MT-1 | 80 km | 1990 | ✅ 运营中 |  |
| Almería-Melilla (ALME) | 198 km | 1990 | ✅ 运营中 |  |
| Rønne-Rødvig | 153 km | 1989 | ✅ 运营中 |  |
