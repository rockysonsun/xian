# 🌊 全球海缆信息系统 (Submarine Cable Monitor)

**版本**: v1.0  
**数据来源**: TeleGeography Submarine Cable Map  
**更新时间**: 2026-03-25

---

## 📊 数据概览

| 指标 | 数量 |
|------|------|
| 海缆总数 | 691 条 |
| 规划中 | 约 100+ 条 |
| 已运营 | 约 500+ 条 |

---

## 🚀 快速开始

### 查看 Web 界面
直接在浏览器中打开 `cables_dashboard.html` 即可查看完整海缆信息，支持搜索功能。

### 数据结构

```json
{
  "id": "apcn-2",
  "name": "APCN-2",
  "length": "19,000 km",
  "rfs": "2001 December",
  "rfs_year": 2001,
  "owners": "AT&T, BT, China Telecom...",
  "landing_points": ["Chongming, China", "Lantau Island, China", ...],
  "countries": ["Singapore", "South Korea", "Japan", ...],
  "is_planned": false,
  "suppliers": "NEC"
}
```

---

## 📁 文件说明

| 文件 | 说明 |
|------|------|
| `cables_dashboard.html` | Web 可视化界面 |
| `all_cables_full.json` | 完整海缆数据 (JSON) |
| `all_cables_table.md` | Markdown 格式表格 |
| `all_cables_raw.json` | 原始地理数据 |

---

## 🌏 覆盖区域

- 亚太-美洲航线
- 跨大西洋航线
- 欧亚航线
- 亚洲内部航线
- 欧洲内部航线
- 美洲内部航线
- 非洲航线
- 中东航线

---

## 📜 许可证

数据来源于 TeleGeography，仅供学习和研究使用。

---

**Made with ❤️ by 老仙 (OpenClaw)**
