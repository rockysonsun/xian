---
name: submarine-cable-monitor
description: Monitor global submarine cable network status and outages. Use when user asks about submarine cable status, internet backbone health, trans-oceanic network connectivity, or cable outage alerts. Supports checking specific cable routes (Asia-America, Europe-Asia, etc.), monitoring latency changes, and receiving outage notifications.
---

# Submarine Cable Monitor

Monitor global submarine cable infrastructure status and receive outage alerts.

## Overview

This skill tracks the health of major submarine cable systems worldwide using real data from TeleGeography and news monitoring.

**Monitored Regions:**
- 🌏 Trans-Pacific routes (Asia-America)
- 🌊 Trans-Atlantic routes (Europe-America)
- 🌏 Intra-Asia routes
- 🌍 Europe-Asia routes

## Quick Start

### Check Cable Status

```bash
# Check all major cables (uses cached data)
python3 scripts/check_cables.py

# Refresh data from sources
python3 scripts/check_cables.py --refresh

# Check specific region
python3 scripts/check_cables.py --region asia-america

# Check specific cable
python3 scripts/check_cables.py --cable "APCN-2"

# List all monitored cables
python3 scripts/check_cables.py --list

# Output as JSON
python3 scripts/check_cables.py --json
```

### Data Sources

```bash
# Fetch static cable data from TeleGeography
python3 scripts/fetch_real_data.py --save-cache

# Fetch outage news from Google/Reddit
python3 scripts/fetch_outage_news.py --save-cache

# Get unified data (combines both sources)
python3 scripts/cable_data.py
```

### Setup Monitoring (Coming Soon)

```bash
# Start continuous monitoring (checks every 5 minutes)
python3 scripts/monitor.py --interval 300

# Setup webhook alerts
python3 scripts/monitor.py --webhook "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=YOUR_KEY"
```

## Features

- ✅ **Real Cable Data**: Fetches from TeleGeography's public API (691+ cables)
- 📰 **Outage Monitoring**: Scrapes news/social media for outage reports
- 🔄 **Unified View**: Combines static data + outage alerts
- 💾 **Smart Caching**: Avoids unnecessary API calls
- 📊 **Status Summary**: Operational / Degraded / Outage / Unknown
- 🌐 **Multi-Region**: Asia-America, Trans-Atlantic, Europe-Asia, Intra-Asia

## Data Sources

| Source | Type | Data |
|--------|------|------|
| TeleGeography | Static | Cable info, length, landing points, RFS |
| Google News | Real-time | Outage reports, maintenance news |
| Reddit | Community | r/networking, r/sysadmin discussions |

## Commands

### Check Cable Status

```
Check submarine cable status
Is APCN-2 cable working?
Show me trans-pacific cable health
Any cable outages today?
```

### Setup Monitoring

```
Start monitoring submarine cables
Alert me when cables go down
Setup cable outage notifications
```

### Query Specific Routes

```
Check Asia-America cable routes
Status of cables connecting to Japan
Europe-Asia cable health
```

## Configuration

Create `config.json` in the skill directory:

```json
{
  "webhook_url": "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=YOUR_KEY",
  "check_interval": 300,
  "regions": ["asia-america", "europe-asia", "trans-atlantic"],
  "alert_on_latency_spike": true,
  "latency_threshold_ms": 100
}
```

## File Structure

```
submarine-cable-monitor/
├── SKILL.md                          # This file
├── scripts/
│   ├── check_cables.py              # Main status checker (updated with real data)
│   ├── fetch_real_data.py           # TeleGeography API fetcher
│   ├── fetch_outage_news.py         # News/social media monitor
│   ├── cable_data.py                # Unified data source
│   └── monitor.py                   # Continuous monitoring (WIP)
├── references/
│   ├── api-docs.md                  # API documentation
│   └── cables.md                    # Cable database reference
├── cable_data_cache.json            # Cached TeleGeography data
└── outage_cache.json                # Cached outage news
```

## Monitored Cables

### Asia-America (7 cables)
- APCN-2, FASTER, AAG, APG, PLCN, SEA-US, TGN-Pacific

### Trans-Atlantic (4 cables)
- MAREA, Amitié, Dunant, Apollo

### Europe-Asia (3 cables)
- AAE-1, IMEWE

### Intra-Asia (2 cables)
- ASE/Cahaya Malaysia, EAC-C2C

## References

- [API Documentation](references/api-docs.md) - Data source APIs and endpoints
- [Cable Database](references/cables.md) - List of monitored cables and their routes
- [Alert Format](references/alerts.md) - Webhook alert message format

## Notes

- TeleGeography provides static cable info (no real-time status)
- Outage detection relies on news/social media monitoring
- Some cables may not be found due to naming differences
- Data accuracy depends on public sources and may have delays
- For production use, consider subscribing to commercial monitoring services

## TODO

- [x] P0: Integrate TeleGeography API for real cable data
- [x] P1: Add news/social media outage monitoring
- [ ] P2: Setup automated cron-based monitoring
- [ ] P3: Integrate with 企业微信 webhook for alerts
- [ ] P4: Add latency monitoring via ping probes
