#!/usr/bin/env python3
"""
批量获取海缆详细信息并生成汇总文件
"""
import json
import time
import urllib.request
import urllib.error
from datetime import datetime

# 读取cable IDs
with open('cable_ids.txt', 'r') as f:
    cable_ids = [line.strip() for line in f.readlines()]

print(f"Total cables to fetch: {len(cable_ids)}")

# 存储结果
successful = []
failed = []
failed_ids = []

# 批量获取每条海缆的详细信息
for idx, cable_id in enumerate(cable_ids):
    url = f"https://www.submarinecablemap.com/api/v3/cable/{cable_id}.json"
    
    try:
        # 添加请求头模拟浏览器
        req = urllib.request.Request(
            url,
            headers={
                'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept': 'application/json'
            }
        )
        
        with urllib.request.urlopen(req, timeout=30) as response:
            data = json.loads(response.read().decode('utf-8'))
            
            # 提取需要的字段
            cable_info = {
                'name': data.get('name', ''),
                'id': data.get('id', cable_id),
                'length': data.get('length', ''),
                'rfs': data.get('rfs', ''),
                'rfs_year': data.get('rfs_year', ''),
                'owners': data.get('owners', []),
                'landing_points': data.get('landing_points', []),
                'countries': data.get('countries', []),
                'is_planned': data.get('is_planned', False),
                'suppliers': data.get('suppliers', [])
            }
            
            successful.append(cable_info)
            
            if (idx + 1) % 50 == 0:
                print(f"[{datetime.now().strftime('%H:%M:%S')}] Fetched {idx + 1}/{len(cable_ids)} cables...")
                
    except Exception as e:
        failed.append({'id': cable_id, 'error': str(e)})
        failed_ids.append(cable_id)
        print(f"Error fetching {cable_id}: {e}")
    
    # 添加延迟避免请求过快 (0.15秒)
    time.sleep(0.15)

print(f"\n=== Summary ===")
print(f"Successfully fetched: {len(successful)}")
print(f"Failed: {len(failed)}")

# 保存完整JSON文件
with open('all_cables_full.json', 'w', encoding='utf-8') as f:
    json.dump({
        'cables': successful,
        'failed': failed,
        'summary': {
            'total': len(cable_ids),
            'successful': len(successful),
            'failed': len(failed),
            'generated_at': datetime.now().isoformat()
        }
    }, f, ensure_ascii=False, indent=2)

print(f"Saved full data to all_cables_full.json")

# 生成Markdown表格
md_lines = ['# Submarine Cables Summary\n']
md_lines.append(f"_Generated at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}_\n")
md_lines.append(f"_Total: {len(successful)} cables successfully fetched, {len(failed)} failed_\n\n")

md_lines.append('| Name | Length | RFS Year | Status | Countries |')
md_lines.append('|------|--------|----------|--------|-----------|')

for cable in successful:
    name = cable['name'] or cable['id']
    length = cable['length'] or 'N/A'
    rfs_year = cable['rfs_year'] or 'N/A'
    status = 'Planned' if cable['is_planned'] else 'Active'
    countries = ', '.join(cable['countries'][:3]) if cable['countries'] else 'N/A'
    if len(cable['countries']) > 3:
        countries += '...'
    
    md_lines.append(f"| {name} | {length} | {rfs_year} | {status} | {countries} |")

# 添加失败列表
if failed:
    md_lines.append('\n\n## Failed to Fetch\n')
    md_lines.append('| Cable ID | Error |')
    md_lines.append('|----------|-------|')
    for f in failed[:20]:  # 只显示前20个失败
        md_lines.append(f"| {f['id']} | {f['error'][:50]}... |")
    if len(failed) > 20:
        md_lines.append(f"| ... | ... ({len(failed) - 20} more) |")

with open('all_cables_table.md', 'w', encoding='utf-8') as f:
    f.write('\n'.join(md_lines))

print(f"Saved markdown table to all_cables_table.md")
print("Done!")
