# Cable Database

Monitored submarine cable systems organized by region.

## Asia-America Routes

### APCN-2 (Asia-Pacific Cable Network 2)
- **Route**: Japan - Korea - China - Taiwan - Hong Kong - Philippines - Malaysia - Singapore
- **Length**: ~19,000 km
- **Capacity**: 2.56 Tbps
- **RFS**: 2001
- **Status**: Operational

### China-US CN
- **Route**: China - Korea - Japan - US (California)
- **Length**: ~11,000 km
- **RFS**: 2000
- **Status**: Operational

### FASTER
- **Route**: Japan - US (California)
- **Length**: ~11,629 km
- **Capacity**: 60 Tbps
- **RFS**: 2016
- **Status**: Operational
- **Note**: Google-backed cable

### New Cross Pacific (NCP)
- **Route**: China - Korea - Japan - US
- **Length**: ~13,800 km
- **Capacity**: 80 Tbps
- **RFS**: 2018
- **Status**: Operational

### Pacific Light Cable Network (PLCN)
- **Route**: Hong Kong - US (California)
- **Length**: ~12,800 km
- **Capacity**: 144 Tbps
- **RFS**: 2022
- **Status**: Operational

### SEA-US
- **Route**: California - Hawaii - Guam - Philippines - Indonesia
- **Length**: ~15,000 km
- **Capacity**: 20 Tbps
- **RFS**: 2017
- **Status**: Operational

### TGN-Pacific
- **Route**: Japan - US (California)
- **Length**: ~9,000 km
- **RFS**: 2003
- **Status**: Operational

## Trans-Atlantic Routes

### MAREA
- **Route**: Virginia Beach (US) - Bilbao (Spain)
- **Length**: ~6,600 km
- **Capacity**: 200 Tbps
- **RFS**: 2018
- **Status**: Operational
- **Note**: Microsoft-Facebook consortium

### Amitié
- **Route**: Lynn (US) - Bordeaux (France)
- **Length**: ~6,800 km
- **Capacity**: 400 Tbps
- **RFS**: 2023
- **Status**: Operational

### Dunant
- **Route**: Virginia Beach (US) - Saint-Hilaire-de-Riez (France)
- **Length**: ~6,600 km
- **Capacity**: 250 Tbps
- **RFS**: 2021
- **Status**: Operational
- **Note**: Google-owned

### TAT-14
- **Route**: Europe - US
- **Length**: ~15,428 km
- **RFS**: 2001
- **Status**: Operational

### Apollo
- **Route**: UK - France - US
- **Length**: ~13,000 km
- **RFS**: 2003
- **Status**: Operational

## Europe-Asia Routes

### SEA-ME-WE 3
- **Route**: Europe - Middle East - Asia
- **Length**: ~39,000 km
- **RFS**: 1999
- **Status**: Operational
- **Note**: Longest submarine cable system

### SEA-ME-WE 5
- **Route**: France - Singapore
- **Length**: ~20,000 km
- **Capacity**: 24 Tbps
- **RFS**: 2016
- **Status**: Operational

### AAE-1 (Asia-Africa-Europe 1)
- **Route**: Asia - Middle East - Europe
- **Length**: ~25,000 km
- **Capacity**: 40 Tbps
- **RFS**: 2017
- **Status**: Operational

### IMEWE
- **Route**: India - Middle East - Europe
- **Length**: ~12,091 km
- **Capacity**: 3.84 Tbps
- **RFS**: 2010
- **Status**: Operational

## Intra-Asia Routes

### EAC-C2C
- **Route**: Intra-Asia ring
- **Length**: ~17,000 km
- **Capacity**: 2.56 Tbps
- **RFS**: 2002
- **Status**: Operational

### TGN-Intra Asia
- **Route**: Japan - Hong Kong - Singapore
- **Length**: ~6,700 km
- **RFS**: 2009
- **Status**: Operational

### Asia Submarine-cable Express (ASE)
- **Route**: Japan - Hong Kong - Singapore
- **Length**: ~7,800 km
- **Capacity**: 15 Tbps
- **RFS**: 2012
- **Status**: Operational

## Data Sources

- TeleGeography Submarine Cable Map: https://www.submarinecablemap.com/
- Infrapedia: https://www.infrapedia.com/
- Cable.co.uk: https://www.cable.co.uk/submarine-cable-map/

## Notes

- Cable status is monitored through public outage reports and latency measurements
- Actual capacity may be upgraded beyond original design
- RFS = Ready for Service date