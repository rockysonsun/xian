# API Documentation

Data sources and APIs for submarine cable monitoring.

## Public Data Sources

### 1. Infrapedia
**URL**: https://www.infrapedia.com/

Global internet infrastructure map with API access.

**Features**:
- Real-time cable status
- Outage notifications
- Network topology
- Latency data

**API Access**:
- Requires API key for full access
- Free tier available with limited queries
- GraphQL endpoint available

### 2. TeleGeography Submarine Cable Map
**URL**: https://www.submarinecablemap.com/

Industry-standard cable map with detailed information.

**Features**:
- Comprehensive cable database
- Route visualization
- Ownership information
- Capacity data

**Data Access**:
- Public map interface
- Data available via subscription
- API access for enterprise customers

### 3. Cloudflare Radar
**URL**: https://radar.cloudflare.com/

Internet outage detection and network insights.

**API Endpoint**:
```
https://api.cloudflare.com/client/v4/radar/
```

**Features**:
- Global outage detection
- BGP monitoring
- Latency measurements
- Country-level connectivity

**Authentication**: Requires Cloudflare API token

### 4. ThousandEyes
**URL**: https://www.thousandeyes.com/

Network monitoring platform with internet outage detection.

**Features**:
- Path visualization
- Outage detection
- Performance monitoring
- BGP route tracking

**Note**: Commercial service, requires subscription

### 5. RIPE Atlas
**URL**: https://atlas.ripe.net/

Global internet measurement network.

**API Endpoint**:
```
https://atlas.ripe.net/api/v2/
```

**Features**:
- Ping measurements from global probes
- Traceroute data
- DNS monitoring
- Free API access

## Simulated Data

Current implementation uses a simulated database for demonstration.

To integrate real data:

1. **Sign up for APIs**:
   - Infrapedia API key
   - Cloudflare API token
   - RIPE Atlas account

2. **Update scripts/check_cables.py**:
   ```python
   def fetch_real_time_status():
       # Call actual APIs
       pass
   ```

3. **Add error handling**:
   - API rate limiting
   - Network timeouts
   - Fallback to cached data

## Alert Webhook Format

### WeChat Work (企业微信)

**Endpoint**: `https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=YOUR_KEY`

**Message Format**:
```json
{
  "msgtype": "text",
  "text": {
    "content": "Alert message here"
  }
}
```

**Markdown Format**:
```json
{
  "msgtype": "markdown",
  "markdown": {
    "content": "**Bold** and <font color='warning'>colored</font> text"
  }
}
```

### Slack

**Format**:
```json
{
  "text": "Alert message",
  "attachments": [
    {
      "color": "danger",
      "fields": [
        {"title": "Cable", "value": "APCN-2", "short": true},
        {"title": "Status", "value": "Outage", "short": true}
      ]
    }
  ]
}
```

### Discord

**Format**:
```json
{
  "content": "🚨 Cable Alert",
  "embeds": [
    {
      "title": "APCN-2 Status Change",
      "description": "Cable is experiencing outage",
      "color": 16711680
    }
  ]
}
```

## Rate Limiting

When implementing real API calls:

- **Infrapedia**: 100 requests/minute (free tier)
- **Cloudflare**: 1200 requests/5 minutes
- **RIPE Atlas**: 1000 requests/day (free tier)

Implement caching to avoid hitting limits:
- Cache status for 5 minutes minimum
- Use exponential backoff on errors
- Batch requests where possible