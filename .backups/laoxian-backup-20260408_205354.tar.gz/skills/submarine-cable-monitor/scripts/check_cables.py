#!/usr/bin/env python3
"""
Submarine Cable Status Checker
Monitors global submarine cable network health using real data sources
"""

import argparse
import json
import sys
from datetime import datetime
from typing import Dict, List, Optional
from pathlib import Path

# Add parent directory to path to import cable_data
sys.path.insert(0, str(Path(__file__).parent))
from cable_data import get_unified_cable_data, format_unified_report


def get_all_cables() -> List[Dict]:
    """Get all cables from real data source"""
    data = get_unified_cable_data(use_cache=True, save_cache=False)
    
    all_cables = []
    for region, cables in data.get('regions', {}).items():
        for cable in cables:
            cable_copy = cable.copy()
            cable_copy['region'] = region
            all_cables.append(cable_copy)
    
    return all_cables


def get_cables_by_region(region: str) -> List[Dict]:
    """Get cables for a specific region"""
    data = get_unified_cable_data(use_cache=True, save_cache=False)
    
    cables = data.get('regions', {}).get(region.lower(), [])
    for cable in cables:
        cable['region'] = region.lower()
    return cables


def get_cable_by_name(name: str) -> Optional[Dict]:
    """Find a cable by name"""
    all_cables = get_all_cables()
    
    for cable in all_cables:
        if name.lower() in cable.get('name', '').lower():
            return cable
        if name.lower() == cable.get('id', '').lower():
            return cable
    
    return None


def format_status_report(cables: List[Dict], region: Optional[str] = None) -> str:
    """Format a human-readable status report"""
    lines = []
    
    if region:
        lines.append(f"🌊 Submarine Cable Status - {region.upper().replace('-', ' ')} Region")
    else:
        lines.append("🌊 Global Submarine Cable Status")
    
    lines.append("=" * 60)
    lines.append(f"📅 Data from TeleGeography + News Monitoring")
    lines.append("")
    
    # Calculate summary
    operational = sum(1 for c in cables if c.get('status') == 'operational')
    degraded = sum(1 for c in cables if c.get('status') == 'degraded')
    outage = sum(1 for c in cables if c.get('status') == 'outage')
    unknown = sum(1 for c in cables if c.get('status') not in ['operational', 'degraded', 'outage'])
    
    lines.append(f"📊 Summary: {operational} operational, {degraded} degraded, {outage} outage, {unknown} unknown")
    lines.append("")
    
    # Group by region
    by_region = {}
    for cable in cables:
        r = cable.get('region', 'unknown')
        if r not in by_region:
            by_region[r] = []
        by_region[r].append(cable)
    
    for r, region_cables in sorted(by_region.items()):
        lines.append(f"\n📍 {r.upper().replace('-', ' ')}")
        lines.append("-" * 40)
        
        for cable in region_cables:
            status = cable.get('status', 'unknown')
            status_emoji = {
                'operational': '✅',
                'degraded': '⚠️',
                'outage': '❌',
                'unknown': '❓',
            }.get(status, '❓')
            
            lines.append(f"\n  {status_emoji} {cable['name']}")
            lines.append(f"     ID: {cable.get('id', 'N/A')}")
            lines.append(f"     Length: {cable.get('length', 'N/A')}")
            lines.append(f"     RFS: {cable.get('rfs', 'N/A')}")
            
            countries = cable.get('countries', [])
            if countries:
                lines.append(f"     Route: {', '.join(countries[:3])}")
                if len(countries) > 3:
                    lines.append(f"            ... and {len(countries) - 3} more")
            
            # Show outage info if present
            outage_info = cable.get('outage_info')
            if outage_info:
                lines.append(f"     🚨 Alert: {outage_info.get('snippet', 'N/A')[:60]}...")
    
    lines.append("")
    lines.append(f"Last updated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="Check submarine cable status")
    parser.add_argument("--region", help="Check specific region (asia-america, trans-atlantic, europe-asia, intra-asia)")
    parser.add_argument("--cable", help="Check specific cable by name or ID")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parser.add_argument("--list", action="store_true", help="List all monitored cables")
    parser.add_argument("--refresh", action="store_true", help="Refresh data from sources (ignore cache)")
    
    args = parser.parse_args()
    
    if args.list:
        cables = get_all_cables()
        if args.json:
            print(json.dumps(cables, indent=2, ensure_ascii=False))
        else:
            print("📋 Monitored Submarine Cables:")
            print("=" * 50)
            for cable in cables:
                status_emoji = {
                    'operational': '✅',
                    'degraded': '⚠️',
                    'outage': '❌',
                    'unknown': '❓',
                }.get(cable.get('status'), '❓')
                print(f"  {status_emoji} {cable['name']} ({cable.get('id', 'N/A')})")
        return
    
    # Refresh data if requested
    if args.refresh:
        print("🔄 Refreshing data from sources...")
        data = get_unified_cable_data(use_cache=False, save_cache=True)
    
    if args.cable:
        cable = get_cable_by_name(args.cable)
        if not cable:
            print(f"❌ Cable '{args.cable}' not found")
            print("Use --list to see all monitored cables")
            sys.exit(1)
        
        cables = [cable]
    elif args.region:
        cables = get_cables_by_region(args.region)
        if not cables:
            print(f"❌ Unknown region: {args.region}")
            print("Available regions: asia-america, trans-atlantic, europe-asia, intra-asia")
            sys.exit(1)
    else:
        cables = get_all_cables()
    
    if args.json:
        print(json.dumps(cables, indent=2, ensure_ascii=False))
    else:
        print(format_status_report(cables, args.region))


if __name__ == "__main__":
    main()
