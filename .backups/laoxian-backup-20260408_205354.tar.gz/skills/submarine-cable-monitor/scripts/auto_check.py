#!/usr/bin/env python3
"""
Submarine Cable Monitor - Automated Check with Alerts
Runs cable check and sends webhook alerts if issues detected
"""

import json
import sys
import urllib.request
import urllib.error
from pathlib import Path
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))
from cable_data import get_unified_cable_data

# Webhook URL from config or default
WEBHOOK_URL = "https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=530733ac-2325-499f-88f9-7bbeee786c18"


def send_wechat_alert(message: str):
    """Send alert via WeChat Work webhook"""
    try:
        data = json.dumps({
            "msgtype": "text",
            "text": {
                "content": message
            }
        }).encode('utf-8')
        
        req = urllib.request.Request(
            WEBHOOK_URL,
            data=data,
            headers={'Content-Type': 'application/json'},
            method='POST'
        )
        
        with urllib.request.urlopen(req, timeout=10) as response:
            if response.status == 200:
                print("✅ Alert sent to WeChat Work")
                return True
            else:
                print(f"⚠️ Webhook returned status {response.status}")
                return False
    
    except Exception as e:
        print(f"❌ Failed to send alert: {e}")
        return False


def check_and_alert():
    """Main check function - runs every 12 hours"""
    print("=" * 60)
    print("🌊 星宿老仙海缆监控系统 - 定时检查")
    print(f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("=" * 60)
    print()
    
    # Fetch fresh data
    print("📡 正在获取最新数据...")
    data = get_unified_cable_data(use_cache=False, save_cache=True)
    
    summary = data.get('summary', {})
    total = summary.get('total_cables', 0)
    operational = summary.get('operational', 0)
    degraded = summary.get('degraded', 0)
    outage = summary.get('outage', 0)
    unknown = summary.get('unknown', 0)
    
    print()
    print("📊 检查结果:")
    print(f"   监控海缆总数: {total}")
    print(f"   ✅ 正常: {operational}")
    print(f"   ⚠️  降级: {degraded}")
    print(f"   ❌ 中断: {outage}")
    print(f"   ❓ 未知: {unknown}")
    print()
    
    # Check for issues
    issues = []
    for region, cables in data.get('regions', {}).items():
        for cable in cables:
            status = cable.get('status', 'unknown')
            if status in ['degraded', 'outage']:
                issues.append({
                    'name': cable.get('name', 'Unknown'),
                    'id': cable.get('id', 'N/A'),
                    'status': status,
                    'region': region,
                    'outage_info': cable.get('outage_info', {})
                })
    
    # Send alert if issues found
    if issues:
        print(f"🚨 检测到 {len(issues)} 条海缆异常!")
        print()
        
        # Build alert message
        alert_msg = f"🚨 星宿老仙海缆监控告警\n"
        alert_msg += f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n"
        alert_msg += f"\n检测到 {len(issues)} 条海缆状态异常:\n\n"
        
        for issue in issues:
            status_text = "❌ 中断" if issue['status'] == 'outage' else "⚠️ 降级"
            alert_msg += f"{status_text} {issue['name']}\n"
            alert_msg += f"   区域: {issue['region'].upper().replace('-', ' ')}\n"
            
            outage_info = issue.get('outage_info', {})
            if outage_info.get('snippet'):
                snippet = outage_info['snippet'][:80]
                alert_msg += f"   详情: {snippet}...\n"
            alert_msg += "\n"
        
        alert_msg += "📡 数据来源: TeleGeography + 新闻监控\n"
        alert_msg += "💡 请核实官方运营商公告"
        
        print("📤 正在发送告警...")
        send_wechat_alert(alert_msg)
        
    else:
        print("✅ 所有监控海缆运行正常")
        print()
        print("💡 12小时后进行下一次检查")
    
    print()
    print("=" * 60)
    return len(issues)


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Automated cable check with alerts")
    parser.add_argument("--test-alert", action="store_true", help="Send test alert")
    
    args = parser.parse_args()
    
    if args.test_alert:
        print("📤 Sending test alert...")
        test_msg = f"🧪 星宿老仙海缆监控测试\n\n"
        test_msg += f"这是一条测试消息\n"
        test_msg += f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n"
        test_msg += f"如果收到此消息，说明告警系统工作正常 ✅"
        
        if send_wechat_alert(test_msg):
            print("✅ Test alert sent successfully")
        else:
            print("❌ Test alert failed")
        return
    
    # Run normal check
    issue_count = check_and_alert()
    sys.exit(issue_count)  # Exit with count of issues (0 = OK)


if __name__ == "__main__":
    main()
