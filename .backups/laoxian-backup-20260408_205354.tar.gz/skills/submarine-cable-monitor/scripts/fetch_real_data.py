#!/usr/bin/env python3
"""
Real-time submarine cable data fetcher
Fetches data from TeleGeography and other public APIs
"""

import json
import urllib.request
import urllib.error
from typing import Dict, List, Optional
from datetime import datetime

# TeleGeography API endpoints
TELEGEOGRAPHY_BASE = "https://www.submarinecablemap.com/api/v3"

# Cable IDs we want to monitor (from our database)
MONITORED_CABLES = {
    "asia-america": [
        "apcn-2",
        "faster", 
        "asia-america-gateway-aag-cable-system",
        "asia-pacific-gateway-apg",
        "new-cross-pacific-ncp",
        "pacific-light-cable-network-plcn",
        "sea-us",
        "tgn-pacific",
    ],
    "trans-atlantic": [
        "marea",
        "amitie",
        "dunant",
        "tat-14",
        "apollo",
    ],
    "europe-asia": [
        "asia-africa-europe-1-aae-1",
        "sea-me-we-3",
        "sea-me-we-5",
        "imewe",
    ],
    "intra-asia": [
        "asia-submarine-cable-express-asecahaya-malaysia",
        "tgn-intra-asia",
        "eac-c2c",
    ]
}


def fetch_cable_details(cable_id: str) -> Optional[Dict]:
    """Fetch detailed information for a specific cable from TeleGeography"""
    url = f"{TELEGEOGRAPHY_BASE}/cable/{cable_id}.json"
    
    try:
        req = urllib.request.Request(url, headers={
            'User-Agent': 'Mozilla/5.0 (compatible; OpenClawBot/1.0)'
        })
        
        with urllib.request.urlopen(req, timeout=15) as response:
            if response.status == 200:
                data = json.loads(response.read().decode('utf-8'))
                return {
                    "id": data.get("id"),
                    "name": data.get("name"),
                    "length": data.get("length"),
                    "landing_points": [lp.get("name") for lp in data.get("landing_points", [])],
                    "countries": list(set([lp.get("country") for lp in data.get("landing_points", []) if lp.get("country")])),
                    "owners": data.get("owners"),
                    "rfs": data.get("rfs"),
                    "rfs_year": data.get("rfs_year"),
                    "is_planned": data.get("is_planned", False),
                    "suppliers": data.get("suppliers"),
                }
    except urllib.error.HTTPError as e:
        if e.code == 404:
            print(f"  ⚠️ Cable '{cable_id}' not found in TeleGeography database")
        else:
            print(f"  ❌ HTTP error for {cable_id}: {e.code}")
    except Exception as e:
        print(f"  ❌ Error fetching {cable_id}: {e}")
    
    return None


def fetch_all_cables_list() -> List[Dict]:
    """Fetch list of all cables from TeleGeography"""
    url = f"{TELEGEOGRAPHY_BASE}/cable/all.json"
    
    try:
        req = urllib.request.Request(url, headers={
            'User-Agent': 'Mozilla/5.0 (compatible; OpenClawBot/1.0)'
        })
        
        with urllib.request.urlopen(req, timeout=30) as response:
            if response.status == 200:
                return json.loads(response.read().decode('utf-8'))
    except Exception as e:
        print(f"❌ Error fetching cable list: {e}")
    
    return []


def search_cable_id(name: str, all_cables: List[Dict]) -> Optional[str]:
    """Search for cable ID by name"""
    name_lower = name.lower().replace(" ", "-").replace("(", "").replace(")", "")
    
    for cable in all_cables:
        cable_id = cable.get("id", "")
        cable_name = cable.get("name", "").lower()
        
        # Exact match
        if name_lower == cable_id:
            return cable_id
        
        # Name contains search term
        if name_lower in cable_name or cable_name in name_lower:
            return cable_id
    
    return None


def fetch_monitored_cables() -> Dict[str, List[Dict]]:
    """Fetch details for all monitored cables"""
    print("🌊 Fetching submarine cable data from TeleGeography...")
    print()
    
    # First, get the full list to help with ID mapping
    all_cables = fetch_all_cables_list()
    print(f"📊 TeleGeography has {len(all_cables)} cables in database")
    print()
    
    results = {}
    
    for region, cable_ids in MONITORED_CABLES.items():
        print(f"📍 {region.upper().replace('-', ' ')}")
        region_cables = []
        
        for cable_id in cable_ids:
            print(f"  🔍 Fetching {cable_id}...", end=" ")
            details = fetch_cable_details(cable_id)
            
            if details:
                print(f"✅ {details['name']}")
                # Add region info
                details["region"] = region
                # Since TeleGeography doesn't have real-time status, we mark as unknown
                # In production, this would come from outage monitoring services
                details["status"] = "unknown"
                details["last_checked"] = datetime.now().isoformat()
                region_cables.append(details)
            else:
                # Try to find by searching the name
                found_id = search_cable_id(cable_id.replace("-", " "), all_cables)
                if found_id and found_id != cable_id:
                    print(f"🔄 Trying alternate ID: {found_id}...", end=" ")
                    details = fetch_cable_details(found_id)
                    if details:
                        print(f"✅ {details['name']}")
                        details["region"] = region
                        details["status"] = "unknown"
                        details["last_checked"] = datetime.now().isoformat()
                        region_cables.append(details)
                    else:
                        print("❌ Not found")
                else:
                    print("❌ Not found")
        
        results[region] = region_cables
        print()
    
    return results


def save_to_cache(data: Dict, cache_file: str = "cable_data_cache.json"):
    """Save fetched data to cache file"""
    from pathlib import Path
    cache_path = Path(__file__).parent.parent / cache_file
    with open(cache_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    print(f"💾 Data cached to {cache_path}")


def load_from_cache(cache_file: str = "cable_data_cache.json") -> Optional[Dict]:
    """Load data from cache file"""
    from pathlib import Path
    cache_path = Path(__file__).parent.parent / cache_file
    
    if cache_path.exists():
        try:
            with open(cache_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"⚠️ Error loading cache: {e}")
    
    return None


def format_status_report(data: Dict) -> str:
    """Format cable data as human-readable report"""
    lines = []
    lines.append("🌊 Submarine Cable Status Report")
    lines.append("=" * 60)
    lines.append(f"📅 Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"📡 Data Source: TeleGeography Submarine Cable Map")
    lines.append("")
    
    total_cables = 0
    for region, cables in data.items():
        total_cables += len(cables)
    
    lines.append(f"📊 Total Monitored Cables: {total_cables}")
    lines.append("")
    
    for region, cables in sorted(data.items()):
        if not cables:
            continue
            
        lines.append(f"\n📍 {region.upper().replace('-', ' ')}")
        lines.append("-" * 50)
        
        for cable in cables:
            status_emoji = {
                "operational": "✅",
                "degraded": "⚠️",
                "outage": "❌",
                "unknown": "❓"
            }.get(cable.get("status", "unknown"), "❓")
            
            lines.append(f"\n  {status_emoji} {cable['name']}")
            lines.append(f"     ID: {cable['id']}")
            lines.append(f"     Length: {cable.get('length', 'N/A')}")
            lines.append(f"     RFS: {cable.get('rfs', 'N/A')}")
            
            countries = cable.get('countries', [])
            if countries:
                lines.append(f"     Countries: {', '.join(countries[:5])}")
                if len(countries) > 5:
                    lines.append(f"                ... and {len(countries) - 5} more")
    
    lines.append("")
    lines.append("=" * 60)
    lines.append("💡 Note: Real-time status requires additional outage monitoring sources")
    
    return "\n".join(lines)


def main():
    import argparse
    from pathlib import Path
    
    parser = argparse.ArgumentParser(description="Fetch real submarine cable data")
    parser.add_argument("--cache", action="store_true", help="Use cached data if available")
    parser.add_argument("--save-cache", action="store_true", help="Save fetched data to cache")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parser.add_argument("--region", help="Filter by region")
    
    args = parser.parse_args()
    
    data = None
    
    # Try to load from cache if requested
    if args.cache:
        data = load_from_cache()
        if data:
            print("📂 Loaded data from cache")
    
    # Fetch fresh data if not cached or cache disabled
    if not data:
        data = fetch_monitored_cables()
        
        if args.save_cache:
            save_to_cache(data)
    
    # Filter by region if specified
    if args.region:
        if args.region in data:
            data = {args.region: data[args.region]}
        else:
            print(f"❌ Unknown region: {args.region}")
            print(f"Available: {', '.join(data.keys())}")
            return
    
    # Output
    if args.json:
        print(json.dumps(data, indent=2, ensure_ascii=False))
    else:
        print(format_status_report(data))


if __name__ == "__main__":
    main()
