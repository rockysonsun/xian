#!/usr/bin/env python3
"""
Submarine Cable Outage News Monitor
Scrapes news and social media for cable outage reports
"""

import json
import urllib.request
import urllib.error
import urllib.parse
import re
from typing import List, Dict, Optional
from datetime import datetime, timedelta
from pathlib import Path

# Keywords to search for cable outages
OUTAGE_KEYWORDS = [
    "submarine cable outage",
    "submarine cable fault",
    "undersea cable cut",
    "submarine cable break",
    "cable system outage",
    "APCN-2 outage",
    "FASTER cable",
    "SEA-ME-WE",
    "AAE-1 cable",
    "trans-pacific cable",
    "trans-atlantic cable",
]

# Cable name mappings for detection
CABLE_NAME_PATTERNS = {
    "apcn-2": ["APCN-2", "APCN2", "Asia-Pacific Cable Network 2"],
    "faster": ["FASTER", "Faster Cable"],
    "asia-america-gateway-aag-cable-system": ["AAG", "Asia-America Gateway"],
    "asia-pacific-gateway-apg": ["APG", "Asia Pacific Gateway"],
    "pacific-light-cable-network-plcn": ["PLCN", "Pacific Light Cable Network"],
    "sea-us": ["SEA-US", "SEAUS"],
    "tata-tgn-pacific": ["TGN-Pacific", "Tata TGN"],
    "marea": ["MAREA"],
    "amitie": ["Amitié", "Amitie"],
    "dunant": ["Dunant"],
    "apollo": ["Apollo", "Apollo cable"],
    "asia-africa-europe-1-aae-1": ["AAE-1", "AAE1", "Asia Africa Europe"],
    "imewe": ["IMEWE", "IMWE"],
    "asia-submarine-cable-express-asecahaya-malaysia": ["ASE", "Asia Submarine-cable Express", "Cahaya Malaysia"],
    "eac-c2c": ["EAC-C2C", "EAC C2C"],
}


def fetch_rss_feed(url: str) -> Optional[str]:
    """Fetch RSS feed content"""
    try:
        req = urllib.request.Request(url, headers={
            'User-Agent': 'Mozilla/5.0 (compatible; OpenClawBot/1.0)',
            'Accept': 'application/rss+xml, application/xml, text/xml'
        })
        
        with urllib.request.urlopen(req, timeout=15) as response:
            if response.status == 200:
                return response.read().decode('utf-8', errors='ignore')
    except Exception as e:
        print(f"  ⚠️ Error fetching {url}: {e}")
    
    return None


def parse_outage_from_text(text: str, source: str) -> List[Dict]:
    """Parse text for cable outage mentions"""
    outages = []
    text_lower = text.lower()
    
    # Check for outage-related keywords
    has_outage_keyword = any(keyword.lower() in text_lower for keyword in OUTAGE_KEYWORDS)
    
    if not has_outage_keyword:
        return outages
    
    # Check which cables are mentioned
    for cable_id, patterns in CABLE_NAME_PATTERNS.items():
        for pattern in patterns:
            if pattern.lower() in text_lower:
                # Determine severity
                severity = "unknown"
                if any(word in text_lower for word in ["cut", "break", "severed", "complete outage"]):
                    severity = "outage"
                elif any(word in text_lower for word in ["degraded", "partial", "slow", "latency", "issue"]):
                    severity = "degraded"
                elif any(word in text_lower for word in ["restore", "fixed", "repaired", "back online"]):
                    severity = "restored"
                
                outage = {
                    "cable_id": cable_id,
                    "cable_name": patterns[0],
                    "severity": severity,
                    "source": source,
                    "snippet": text[:200] + "..." if len(text) > 200 else text,
                    "detected_at": datetime.now().isoformat(),
                }
                outages.append(outage)
                break  # Only record once per cable
    
    return outages


def check_google_news() -> List[Dict]:
    """Check Google News for cable outage reports"""
    print("🔍 Checking Google News...")
    outages = []
    
    # Google News RSS for submarine cable related news
    queries = [
        "submarine+cable+outage",
        "undersea+cable+fault",
        "APCN-2+cable",
        "FASTER+cable+Japan",
    ]
    
    for query in queries:
        # Note: Google News RSS is rate limited and may block
        url = f"https://news.google.com/rss/search?q={query}&hl=en-US&gl=US&ceid=US:en"
        
        content = fetch_rss_feed(url)
        if content:
            # Simple parsing - look for item titles and descriptions
            items = re.findall(r'<item>.*?</item>', content, re.DOTALL)
            for item in items[:5]:  # Check first 5 items
                title_match = re.search(r'<title>(.*?)</title>', item, re.DOTALL)
                desc_match = re.search(r'<description>(.*?)</description>', item, re.DOTALL)
                
                if title_match:
                    title = title_match.group(1)
                    desc = desc_match.group(1) if desc_match else ""
                    full_text = f"{title} {desc}"
                    
                    item_outages = parse_outage_from_text(full_text, f"Google News: {query}")
                    outages.extend(item_outages)
    
    print(f"  Found {len(outages)} potential outage mentions")
    return outages


def check_reddit() -> List[Dict]:
    """Check Reddit for cable outage discussions"""
    print("🔍 Checking Reddit...")
    outages = []
    
    # Reddit has a JSON API for public subreddits
    subreddits = ["networking", "sysadmin", "outages"]
    
    for subreddit in subreddits:
        url = f"https://www.reddit.com/r/{subreddit}/search.json?q=submarine+cable&sort=new&limit=10"
        
        try:
            req = urllib.request.Request(url, headers={
                'User-Agent': 'Mozilla/5.0 (compatible; OpenClawBot/1.0)',
            })
            
            with urllib.request.urlopen(req, timeout=15) as response:
                if response.status == 200:
                    data = json.loads(response.read().decode('utf-8'))
                    posts = data.get('data', {}).get('children', [])
                    
                    for post in posts:
                        post_data = post.get('data', {})
                        title = post_data.get('title', '')
                        selftext = post_data.get('selftext', '')
                        full_text = f"{title} {selftext}"
                        
                        item_outages = parse_outage_from_text(full_text, f"Reddit r/{subreddit}")
                        outages.extend(item_outages)
        
        except urllib.error.HTTPError as e:
            if e.code == 429:
                print(f"  ⚠️ Reddit rate limited")
            else:
                print(f"  ⚠️ Reddit error: {e}")
        except Exception as e:
            print(f"  ⚠️ Error checking Reddit: {e}")
    
    print(f"  Found {len(outages)} potential outage mentions")
    return outages


def check_telegeography_status() -> List[Dict]:
    """Check TeleGeography for any status updates"""
    print("🔍 Checking TeleGeography...")
    outages = []
    
    # TeleGeography blog sometimes has outage reports
    url = "https://www2.telegeography.com/blog/rss.xml"
    
    content = fetch_rss_feed(url)
    if content:
        items = re.findall(r'<item>.*?</item>', content, re.DOTALL)
        for item in items[:10]:
            title_match = re.search(r'<title>(.*?)</title>', item, re.DOTALL)
            if title_match:
                title = title_match.group(1)
                item_outages = parse_outage_from_text(title, "TeleGeography Blog")
                outages.extend(item_outages)
    
    print(f"  Found {len(outages)} potential outage mentions")
    return outages


def fetch_outage_data() -> Dict:
    """Fetch outage data from all sources"""
    print("🌊 Fetching submarine cable outage news...")
    print(f"📅 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    all_outages = []
    
    # Check various sources
    all_outages.extend(check_google_news())
    all_outages.extend(check_reddit())
    all_outages.extend(check_telegeography_status())
    
    # Deduplicate by cable_id
    seen_cables = set()
    unique_outages = []
    for outage in all_outages:
        if outage['cable_id'] not in seen_cables:
            seen_cables.add(outage['cable_id'])
            unique_outages.append(outage)
    
    result = {
        "checked_at": datetime.now().isoformat(),
        "total_outages_found": len(unique_outages),
        "outages": unique_outages,
    }
    
    return result


def save_outage_cache(data: Dict, cache_file: str = "outage_cache.json"):
    """Save outage data to cache"""
    cache_path = Path(__file__).parent.parent / cache_file
    with open(cache_path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    print(f"\n💾 Outage data cached to {cache_path}")


def load_outage_cache(cache_file: str = "outage_cache.json") -> Optional[Dict]:
    """Load outage data from cache"""
    cache_path = Path(__file__).parent.parent / cache_file
    if cache_path.exists():
        try:
            with open(cache_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception as e:
            print(f"⚠️ Error loading cache: {e}")
    return None


def format_outage_report(data: Dict) -> str:
    """Format outage data as human-readable report"""
    lines = []
    lines.append("🚨 Submarine Cable Outage Report")
    lines.append("=" * 60)
    lines.append(f"📅 Checked: {data.get('checked_at', 'Unknown')}")
    lines.append(f"📊 Outages Found: {data.get('total_outages_found', 0)}")
    lines.append("")
    
    outages = data.get('outages', [])
    
    if not outages:
        lines.append("✅ No cable outages detected in recent news")
    else:
        for outage in outages:
            severity_emoji = {
                "outage": "❌",
                "degraded": "⚠️",
                "restored": "✅",
                "unknown": "❓"
            }.get(outage.get('severity'), "❓")
            
            lines.append(f"\n{severity_emoji} {outage.get('cable_name', 'Unknown Cable')}")
            lines.append(f"   ID: {outage.get('cable_id', 'N/A')}")
            lines.append(f"   Status: {outage.get('severity', 'unknown').upper()}")
            lines.append(f"   Source: {outage.get('source', 'Unknown')}")
            if outage.get('snippet'):
                lines.append(f"   Snippet: {outage.get('snippet')}")
    
    lines.append("")
    lines.append("=" * 60)
    lines.append("💡 Note: This is automated detection from public sources")
    lines.append("   Always verify with official cable operator announcements")
    
    return "\n".join(lines)


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Monitor submarine cable outages")
    parser.add_argument("--cache", action="store_true", help="Use cached data if available")
    parser.add_argument("--save-cache", action="store_true", help="Save fetched data to cache")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    
    args = parser.parse_args()
    
    data = None
    
    # Try to load from cache
    if args.cache:
        data = load_outage_cache()
        if data:
            print("📂 Loaded data from cache")
    
    # Fetch fresh data
    if not data:
        data = fetch_outage_data()
        
        if args.save_cache:
            save_outage_cache(data)
    
    # Output
    if args.json:
        print(json.dumps(data, indent=2, ensure_ascii=False))
    else:
        print()
        print(format_outage_report(data))


if __name__ == "__main__":
    main()
