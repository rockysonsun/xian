#!/usr/bin/env python3
"""
Submarine Cable Monitor
Continuous monitoring with webhook alerts
"""

import argparse
import json
import time
import sys
from datetime import datetime
from pathlib import Path

# Add parent directory to path to import check_cables
sys.path.insert(0, str(Path(__file__).parent))
from check_cables import get_all_cables, check_cable_status, CABLE_DATABASE


def load_config(config_path: str = None) -> dict:
    """Load configuration from config.json"""
    if not config_path:
        config_path = Path(__file__).parent.parent / "config.json"
    
    if Path(config_path).exists():
        with open(config_path, 'r') as f:
            return json.load(f)
    
    # Default config
    return {
        "webhook_url": None,
        "check_interval": 300,  # 5 minutes
        "regions": ["asia-america", "trans-atlantic", "europe-asia", "intra-asia"],
        "alert_on_latency_spike": True,
        "latency_threshold_ms": 100
    }


def send_webhook_alert(webhook_url: str, message: dict):
    """Send alert via webhook (e.g., WeChat Work)"""
    import urllib.request
    import urllib.error
    
    if not webhook_url:
        print("⚠️ No webhook URL configured, skipping alert")
        return
    
    try:
        data = json.dumps(message).encode('utf-8')
        req = urllib.request.Request(
            webhook_url,
            data=data,
            headers={'Content-Type': 'application/json'},
            method='POST'
        )
        
        with urllib.request.urlopen(req, timeout=10) as response:
            if response.status == 200:
                print(f"✅ Alert sent successfully")
            else:
                print(f"⚠️ Webhook returned status {response.status}")
    
    except urllib.error.URLError as e:
        print(f"❌ Failed to send webhook: {e}")
    except Exception as e:
        print(f"❌ Webhook error: {e}")


def format_wechat_message(cables: list, alert_type: str = "status") -> dict:
    """Format message for WeChat Work webhook"""
    
    if alert_type == "outage":
        # Find cables with issues
        issues = [c for c in cables if c.get("status") in ["degraded", "outage"]]
        
        content = f"🚨 海缆告警通知\n"
        content += f"检测到 {len(issues)} 条海缆异常\n\n"
        
        for cable in issues:
            status_text = "中断" if cable["status"] == "outage" else "降级"
            content += f"❌ {cable['name']}\n"
            content += f"   状态: {status_text}\n"
            content += f"   线路: {cable['route']}\n"
            if "issue" in cable:
                content += f"   详情: {cable['issue']}\n"
            content += "\n"
        
        content += f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        
    else:
        # Regular status report
        operational = sum(1 for c in cables if c.get("status") == "operational")
        degraded = sum(1 for c in cables if c.get("status") == "degraded")
        outage = sum(1 for c in cables if c.get("status") == "outage")
        
        content = f"🌊 海缆状态日报\n\n"
        content += f"✅ 正常: {operational}\n"
        content += f"⚠️ 降级: {degraded}\n"
        content += f"❌ 中断: {outage}\n\n"
        
        if outage > 0 or degraded > 0:
            content += "异常线路:\n"
            for cable in cables:
                if cable.get("status") in ["degraded", "outage"]:
                    status_text = "中断" if cable["status"] == "outage" else "降级"
                    content += f"  • {cable['name']} ({status_text})\n"
        
        content += f"\n⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    
    return {
        "msgtype": "text",
        "text": {
            "content": content
        }
    }


def check_and_alert(config: dict, previous_status: dict = None) -> dict:
    """Check cables and send alerts if status changed"""
    
    cables = get_all_cables()
    current_status = {}
    alerts = []
    
    for cable in cables:
        checked = check_cable_status(cable)
        current_status[cable["name"]] = checked["status"]
        
        # Check if status changed
        if previous_status and cable["name"] in previous_status:
            old_status = previous_status[cable["name"]]
            new_status = checked["status"]
            
            if old_status != new_status:
                if new_status in ["degraded", "outage"]:
                    alerts.append({
                        "cable": cable["name"],
                        "from": old_status,
                        "to": new_status,
                        "severity": "high" if new_status == "outage" else "medium"
                    })
                elif old_status in ["degraded", "outage"] and new_status == "operational":
                    alerts.append({
                        "cable": cable["name"],
                        "from": old_status,
                        "to": new_status,
                        "severity": "resolved"
                    })
    
    # Send alerts if any
    if alerts and config.get("webhook_url"):
        print(f"🚨 {len(alerts)} status changes detected, sending alerts...")
        message = format_wechat_message(cables, "outage")
        send_webhook_alert(config["webhook_url"], message)
    
    return current_status


def run_monitor(config: dict):
    """Main monitoring loop"""
    interval = config.get("check_interval", 300)
    webhook_url = config.get("webhook_url")
    
    print(f"🌊 Starting submarine cable monitor")
    print(f"   Check interval: {interval} seconds")
    print(f"   Webhook: {'enabled' if webhook_url else 'disabled'}")
    print(f"   Press Ctrl+C to stop\n")
    
    previous_status = None
    
    try:
        while True:
            print(f"[{datetime.now().strftime('%H:%M:%S')}] Checking cable status...")
            
            previous_status = check_and_alert(config, previous_status)
            
            # Print summary
            cables = get_all_cables()
            operational = sum(1 for c in cables if c.get("status") == "operational")
            degraded = sum(1 for c in cables if c.get("status") == "degraded")
            outage = sum(1 for c in cables if c.get("status") == "outage")
            
            print(f"   Status: {operational} operational, {degraded} degraded, {outage} outage")
            
            time.sleep(interval)
    
    except KeyboardInterrupt:
        print("\n\n👋 Monitor stopped")


def send_test_alert(config: dict):
    """Send a test alert to verify webhook"""
    webhook_url = config.get("webhook_url")
    
    if not webhook_url:
        print("❌ No webhook URL configured")
        print("   Create config.json with webhook_url setting")
        return
    
    print(f"📤 Sending test alert to webhook...")
    
    test_message = {
        "msgtype": "text",
        "text": {
            "content": f"🧪 海缆监控测试消息\n\n这是来自 submarine-cable-monitor 的测试告警。\n\n⏰ {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        }
    }
    
    send_webhook_alert(webhook_url, test_message)


def main():
    parser = argparse.ArgumentParser(description="Monitor submarine cables")
    parser.add_argument("--config", help="Path to config.json")
    parser.add_argument("--interval", type=int, help="Check interval in seconds")
    parser.add_argument("--webhook", help="Webhook URL for alerts")
    parser.add_argument("--test-alert", action="store_true", help="Send test alert")
    parser.add_argument("--once", action="store_true", help="Run once and exit")
    
    args = parser.parse_args()
    
    # Load config
    config = load_config(args.config)
    
    # Override with command line args
    if args.interval:
        config["check_interval"] = args.interval
    if args.webhook:
        config["webhook_url"] = args.webhook
    
    if args.test_alert:
        send_test_alert(config)
    elif args.once:
        print("🔍 Running single check...")
        check_and_alert(config)
    else:
        run_monitor(config)


if __name__ == "__main__":
    main()
