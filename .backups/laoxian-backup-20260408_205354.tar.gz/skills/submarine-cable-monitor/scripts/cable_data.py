#!/usr/bin/env python3
"""
Unified Submarine Cable Data Source
Combines TeleGeography static data with outage news monitoring
"""

import json
import sys
from pathlib import Path
from typing import Dict, List, Optional
from datetime import datetime

# Add parent directory to path
sys.path.insert(0, str(Path(__file__).parent))

from fetch_real_data import fetch_monitored_cables, load_from_cache as load_cable_cache
from fetch_outage_news import fetch_outage_data, load_outage_cache


def merge_cable_data(static_data: Dict, outage_data: Dict) -> Dict:
    """Merge static cable data with outage information"""
    
    # Create a lookup for outages by cable_id
    outage_lookup = {}
    for outage in outage_data.get('outages', []):
        cable_id = outage.get('cable_id')
        if cable_id:
            outage_lookup[cable_id] = outage
    
    # Merge data
    merged = {
        "generated_at": datetime.now().isoformat(),
        "data_sources": {
            "static": "TeleGeography Submarine Cable Map",
            "outages": "News/Social Media Monitoring",
        },
        "regions": {}
    }
    
    for region, cables in static_data.items():
        merged_cables = []
        
        for cable in cables:
            cable_id = cable.get('id')
            
            # Check if there's outage info for this cable
            if cable_id in outage_lookup:
                outage = outage_lookup[cable_id]
                cable['status'] = outage.get('severity', 'unknown')
                cable['outage_info'] = {
                    'detected_at': outage.get('detected_at'),
                    'source': outage.get('source'),
                    'snippet': outage.get('snippet'),
                }
            else:
                # No news means likely operational (but we mark as unknown to be safe)
                cable['status'] = 'operational'  # Assume operational if no bad news
            
            merged_cables.append(cable)
        
        merged['regions'][region] = merged_cables
    
    # Calculate summary
    total = 0
    operational = 0
    degraded = 0
    outage = 0
    unknown = 0
    
    for region_cables in merged['regions'].values():
        for cable in region_cables:
            total += 1
            status = cable.get('status', 'unknown')
            if status == 'operational':
                operational += 1
            elif status == 'degraded':
                degraded += 1
            elif status == 'outage':
                outage += 1
            else:
                unknown += 1
    
    merged['summary'] = {
        'total_cables': total,
        'operational': operational,
        'degraded': degraded,
        'outage': outage,
        'unknown': unknown,
    }
    
    return merged


def format_unified_report(data: Dict) -> str:
    """Format unified data as human-readable report"""
    lines = []
    lines.append("🌊 Submarine Cable Status Report")
    lines.append("=" * 60)
    lines.append(f"📅 Generated: {data.get('generated_at', 'Unknown')}")
    lines.append(f"📡 Data Sources: {data.get('data_sources', {}).get('static')}")
    lines.append(f"📰 Outage Monitor: {data.get('data_sources', {}).get('outages')}")
    lines.append("")
    
    summary = data.get('summary', {})
    lines.append("📊 Summary:")
    lines.append(f"   ✅ Operational: {summary.get('operational', 0)}")
    lines.append(f"   ⚠️  Degraded: {summary.get('degraded', 0)}")
    lines.append(f"   ❌ Outage: {summary.get('outage', 0)}")
    lines.append(f"   ❓ Unknown: {summary.get('unknown', 0)}")
    lines.append("")
    
    for region, cables in sorted(data.get('regions', {}).items()):
        if not cables:
            continue
        
        lines.append(f"\n📍 {region.upper().replace('-', ' ')}")
        lines.append("-" * 50)
        
        for cable in cables:
            status = cable.get('status', 'unknown')
            status_emoji = {
                'operational': '✅',
                'degraded': '⚠️',
                'outage': '❌',
                'unknown': '❓',
                'restored': '✅',
            }.get(status, '❓')
            
            lines.append(f"\n  {status_emoji} {cable['name']}")
            lines.append(f"     Length: {cable.get('length', 'N/A')}")
            lines.append(f"     RFS: {cable.get('rfs', 'N/A')}")
            
            countries = cable.get('countries', [])
            if countries:
                lines.append(f"     Route: {', '.join(countries[:3])}")
                if len(countries) > 3:
                    lines.append(f"            ... and {len(countries) - 3} more")
            
            # Show outage info if present
            outage_info = cable.get('outage_info')
            if outage_info:
                lines.append(f"     🚨 Alert: {outage_info.get('snippet', 'N/A')[:80]}...")
    
    lines.append("")
    lines.append("=" * 60)
    
    return "\n".join(lines)


def get_unified_cable_data(use_cache: bool = True, save_cache: bool = True) -> Dict:
    """Get unified cable data from all sources"""
    
    # Get static data
    print("📡 Fetching static cable data...")
    static_data = None
    if use_cache:
        static_data = load_cable_cache()
    
    if not static_data:
        static_data = fetch_monitored_cables()
        if save_cache:
            from fetch_real_data import save_to_cache
            save_to_cache(static_data)
    
    # Get outage data
    print("\n📰 Fetching outage news...")
    outage_data = None
    if use_cache:
        outage_data = load_outage_cache()
    
    if not outage_data:
        outage_data = fetch_outage_data()
        if save_cache:
            from fetch_outage_news import save_outage_cache
            save_outage_cache(outage_data)
    
    # Merge
    print("\n🔄 Merging data sources...")
    unified = merge_cable_data(static_data, outage_data)
    
    return unified


def main():
    import argparse
    
    parser = argparse.ArgumentParser(description="Get unified submarine cable data")
    parser.add_argument("--no-cache", action="store_true", help="Don't use cached data")
    parser.add_argument("--no-save", action="store_true", help="Don't save to cache")
    parser.add_argument("--json", action="store_true", help="Output as JSON")
    parser.add_argument("--region", help="Filter by region")
    
    args = parser.parse_args()
    
    use_cache = not args.no_cache
    save_cache = not args.no_save
    
    # Get unified data
    data = get_unified_cable_data(use_cache=use_cache, save_cache=save_cache)
    
    # Filter by region if specified
    if args.region:
        regions = data.get('regions', {})
        if args.region in regions:
            data['regions'] = {args.region: regions[args.region]}
            # Recalculate summary
            total = len(regions[args.region])
            data['summary'] = {
                'total_cables': total,
                'operational': sum(1 for c in regions[args.region] if c.get('status') == 'operational'),
                'degraded': sum(1 for c in regions[args.region] if c.get('status') == 'degraded'),
                'outage': sum(1 for c in regions[args.region] if c.get('status') == 'outage'),
                'unknown': sum(1 for c in regions[args.region] if c.get('status') not in ['operational', 'degraded', 'outage']),
            }
        else:
            print(f"❌ Unknown region: {args.region}")
            print(f"Available: {', '.join(regions.keys())}")
            return
    
    # Output
    if args.json:
        print(json.dumps(data, indent=2, ensure_ascii=False))
    else:
        print()
        print(format_unified_report(data))


if __name__ == "__main__":
    main()
